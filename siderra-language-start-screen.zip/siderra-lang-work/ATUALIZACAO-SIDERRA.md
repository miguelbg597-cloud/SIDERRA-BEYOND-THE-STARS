# Atualização do Siderra

Esta atualização parte da versão pixel art existente e amplia o catálogo astronômico da aba **Reais** com estrelas, estrelas de nêutrons e buracos negros adicionais. Os objetos continuam usando as categorias e a renderização já existentes no simulador.

## Importante
- O catálogo contém estimativas científicas que podem variar conforme o método de medição; as descrições sinalizam casos incertos quando relevante.
- Esta edição não substitui a publicação automaticamente. Para atualizar o site, importe/publica o conteúdo do ZIP no mesmo projeto de hospedagem.
- A compilação TypeScript não foi executada neste ambiente porque as dependências locais não estão instaladas.
