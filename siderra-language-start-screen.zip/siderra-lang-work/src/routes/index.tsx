import { createFileRoute } from "@tanstack/react-router";
import { SandboxApp } from "@/components/sandbox/SandboxApp";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <SandboxApp />;
}
