import { useEffect, useRef, useState } from "react";
import {
  Atom,
  BookOpen,
  Circle,
  CircleDot,
  Copy,
  Eclipse,
  Flame,
  Maximize2,
  Music,
  Minus,
  Move,
  Orbit,
  Pause,
  Pin,
  PinOff,
  Play,
  Plus,
  Rocket,
  Sun,
  SunMedium,
  Trash2,
  X,
} from "lucide-react";
import { AmbientMusic, Score } from "@/game/audio";
import { CATALOG, horizonCaption, type CatalogEntry } from "@/game/catalog";
import { render } from "@/game/draw";
import { flingVelocity, Simulation } from "@/game/sim";
import { KIND_LABEL, type Kind, type PresetName, type SpawnTool } from "@/game/types";
import { formatAU, formatDays, formatMass, formatRate } from "@/game/units";

const SAVE_KEY = "siderra.scene.v1";
const LANGUAGE_KEY = "siderra.language.v1";

const CREATE: Array<{ id: Kind; label: string; icon: typeof Sun }> = [
  { id: "star", label: "Estrela", icon: Sun },
  { id: "planet", label: "Rocha", icon: Circle },
  { id: "gas", label: "Gigante", icon: CircleDot },
  { id: "comet", label: "Cometa", icon: Orbit },
  { id: "asteroid", label: "Asteroide", icon: Circle },
  { id: "white-dwarf", label: "Anã branca", icon: SunMedium },
  { id: "neutron", label: "Nêutron", icon: Atom },
  { id: "black-hole", label: "Buraco negro", icon: Eclipse },
];

const PRESETS: Array<{ id: PresetName; label: string }> = [
  { id: "solar", label: "Sistema Solar" },
  { id: "fall", label: "Queda livre" },
  { id: "binary", label: "Binárias" },
  { id: "cluster", label: "Aglomerado" },
  { id: "empty", label: "Vazio" },
  { id: "fictional", label: "Asterion · fictício" },
];

type Hud = {
  time: number;
  count: number;
  rate: number;
  paused: boolean;
  notice: string;
  massMode: "play" | "real";
  guides: boolean;
  trails: boolean;
  gravity: boolean;
  collisions: boolean;
  selected: null | {
    id: number;
    name: string;
    kind: Kind;
    mass: number;
    radius: number;
    speed: number;
    dist: number;
    pinned: boolean;
    catalogId?: string;
    note?: string;
  };
};

function readHud(sim: Simulation): Hud {
  const selected = sim.body(sim.selectedId);
  const anchor = sim.anchor();
  return {
    time: sim.time,
    count: sim.bodies.length,
    rate: sim.timescale,
    paused: sim.paused,
    notice: sim.notice,
    massMode: sim.massMode,
    guides: sim.guides,
    trails: sim.trails,
    gravity: sim.gravity,
    collisions: sim.collisions,
    selected: selected
      ? {
          id: selected.id,
          name: selected.name,
          kind: selected.kind,
          mass: selected.mass,
          radius: selected.radius,
          speed: Math.hypot(selected.vx, selected.vy),
          dist: anchor ? Math.hypot(selected.x - anchor.x, selected.y - anchor.y) : Math.hypot(selected.x, selected.y),
          pinned: selected.pinned,
          catalogId: selected.catalogId,
          note: selected.note,
        }
      : null,
  };
}

export function SandboxApp() {
  const simRef = useRef<Simulation | null>(null);
  if (!simRef.current) simRef.current = new Simulation();
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const toolRef = useRef<SpawnTool>("move");
  const visitRef = useRef<CatalogEntry | null>(null);
  const soundRef = useRef(true);
  const musicRef = useRef<AmbientMusic | null>(null);
  const [musicOn, setMusicOn] = useState(false);
  const [language, setLanguage] = useState<"pt" | "en" | "es" | null>(() => {
    try {
      const saved = window.localStorage.getItem(LANGUAGE_KEY);
      return saved === "pt" || saved === "en" || saved === "es" ? saved : null;
    } catch { return null; }
  });
  const [tool, setTool] = useState<SpawnTool>("move");
  const [visit, setVisit] = useState<CatalogEntry | null>(null);
  const [sheet, setSheet] = useState<"create" | "catalog" | "body" | "more" | null>(null);
  const [preferCatalog, setPreferCatalog] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const [hasSave, setHasSave] = useState(false);
  const [toast, setToast] = useState("");
  const [hud, setHud] = useState<Hud>(() => readHud(simRef.current!));
  const selectedId = hud.selected?.id ?? null;
  const [trackedId, setTrackedId] = useState<number | null>(selectedId);
  if (selectedId !== trackedId) {
    setTrackedId(selectedId);
    if (selectedId != null) setPreferCatalog(false);
  }

  useEffect(() => {
    toolRef.current = tool;
  }, [tool]);
  useEffect(() => {
    visitRef.current = visit;
  }, [visit]);

  useEffect(() => {
    const sim = simRef.current!;
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const score = new Score();
    let raf = 0;
    let last = performance.now();
    let fitted = false;
    const cssSize = { w: 1, h: 1 };
    const arrow = { current: null as { x0: number; y0: number; x1: number; y1: number } | null };
    const hover = { id: null as number | null };
    const pointers = new Map<number, { x: number; y: number }>();

    type Gesture =
      | { type: "pan"; id: number; lx: number; ly: number }
      | { type: "pinch"; dist: number }
      | { type: "body"; id: number; pointer: number; ox: number; oy: number; samples: Sample[] }
      | { type: "fling"; pointer: number; x0: number; y0: number; x1: number; y1: number; t0: number };
    type Sample = { x: number; y: number; t: number };
    let gesture: Gesture | null = null;

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      cssSize.w = Math.max(1, rect.width);
      cssSize.h = Math.max(1, rect.height);
      canvas.width = Math.round(cssSize.w * dpr);
      canvas.height = Math.round(cssSize.h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (!fitted) {
        sim.fit(cssSize.w, cssSize.h, "inner");
        fitted = true;
      }
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(wrap);

    const local = (event: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      return { x: event.clientX - rect.left, y: event.clientY - rect.top };
    };
    const pinchDistance = () => {
      const pts = [...pointers.values()];
      if (pts.length < 2) return 0;
      return Math.hypot(pts[0]!.x - pts[1]!.x, pts[0]!.y - pts[1]!.y);
    };

    const onDown = (event: PointerEvent) => {
      if (visitRef.current) return;
      if (event.button === 2) event.preventDefault();
      score.unlock();
      canvas.setPointerCapture(event.pointerId);
      pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
      if (pointers.size >= 2) {
        sim.dragId = null;
        gesture = { type: "pinch", dist: pinchDistance() || 1 };
        return;
      }
      const p = local(event);
      const world = sim.screenToWorld(p.x, p.y, cssSize.w, cssSize.h);
      if (event.button === 1 || event.button === 2 || event.shiftKey) {
        gesture = { type: "pan", id: event.pointerId, lx: event.clientX, ly: event.clientY };
        return;
      }
      const current = toolRef.current;
      if (current === "move") {
        const hit = sim.hit(world.x, world.y, sim.camera.k);
        if (hit) {
          sim.selectedId = hit.id;
          sim.dragId = hit.id;
          gesture = {
            type: "body",
            id: hit.id,
            pointer: event.pointerId,
            ox: hit.x - world.x,
            oy: hit.y - world.y,
            samples: [{ x: hit.x, y: hit.y, t: performance.now() }],
          };
        } else {
          gesture = { type: "pan", id: event.pointerId, lx: event.clientX, ly: event.clientY };
        }
        return;
      }
      if (current === "erase" || current === "explode") {
        const hit = sim.hit(world.x, world.y, sim.camera.k);
        if (!hit) return;
        if (current === "erase") sim.remove(hit.id);
        else sim.explode(hit.id);
        return;
      }
      gesture = { type: "fling", pointer: event.pointerId, x0: world.x, y0: world.y, x1: world.x, y1: world.y, t0: performance.now() };
      arrow.current = { x0: world.x, y0: world.y, x1: world.x, y1: world.y };
    };

    const onMove = (event: PointerEvent) => {
      if (!pointers.has(event.pointerId) && gesture?.type !== "pan") {
        const p = local(event);
        const world = sim.screenToWorld(p.x, p.y, cssSize.w, cssSize.h);
        hover.id = sim.hit(world.x, world.y, sim.camera.k)?.id ?? null;
        canvas.style.cursor = hover.id ? "grab" : "default";
      }
      if (pointers.has(event.pointerId)) pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
      if (!gesture) return;
      if (gesture.type === "pinch") {
        const dist = pinchDistance();
        if (dist > 0 && gesture.dist > 0) {
          const rect = canvas.getBoundingClientRect();
          sim.zoomAt(rect.width / 2, rect.height / 2, cssSize.w, cssSize.h, dist / gesture.dist);
          gesture.dist = dist;
        }
        return;
      }
      if (gesture.type === "pan" && gesture.id === event.pointerId) {
        sim.camera.x -= (event.clientX - gesture.lx) / sim.camera.k;
        sim.camera.y -= (event.clientY - gesture.ly) / sim.camera.k;
        gesture.lx = event.clientX;
        gesture.ly = event.clientY;
        return;
      }
      const p = local(event);
      const world = sim.screenToWorld(p.x, p.y, cssSize.w, cssSize.h);
      if (gesture.type === "body" && gesture.pointer === event.pointerId) {
        const body = sim.body(gesture.id);
        if (!body) return;
        body.x = world.x + gesture.ox;
        body.y = world.y + gesture.oy;
        gesture.samples.push({ x: body.x, y: body.y, t: performance.now() });
        if (gesture.samples.length > 8) gesture.samples.shift();
        canvas.style.cursor = "grabbing";
        return;
      }
      if (gesture.type === "fling" && gesture.pointer === event.pointerId) {
        gesture.x1 = world.x;
        gesture.y1 = world.y;
        arrow.current = { x0: gesture.x0, y0: gesture.y0, x1: world.x, y1: world.y };
      }
    };

    const finishBody = (g: Extract<Gesture, { type: "body" }>) => {
      const body = sim.body(g.id);
      sim.dragId = null;
      if (!body || g.samples.length < 2) return;
      const first = g.samples[0]!;
      const last = g.samples[g.samples.length - 1]!;
      if (Math.hypot(last.x - first.x, last.y - first.y) < 0.03) return;
      let index = g.samples.length - 1;
      while (index > 0 && last.t - g.samples[index - 1]!.t < 80) index--;
      const origin = g.samples[index]!;
      const dt = Math.max(0.016, (last.t - origin.t) / 1000);
      body.vx = flingVelocity(last.x - origin.x, dt);
      body.vy = flingVelocity(last.y - origin.y, dt);
      body.orbitA = undefined;
    };

    const onUp = (event: PointerEvent) => {
      pointers.delete(event.pointerId);
      if (!gesture) return;
      if (gesture.type === "body" && gesture.pointer === event.pointerId) finishBody(gesture);
      if (gesture.type === "fling" && gesture.pointer === event.pointerId) {
        const dt = Math.max(0.016, (performance.now() - gesture.t0) / 1000);
        const moved = Math.hypot(gesture.x1 - gesture.x0, gesture.y1 - gesture.y0);
        const vx = moved < 0.04 ? 0 : flingVelocity(gesture.x1 - gesture.x0, dt);
        const vy = moved < 0.04 ? 0 : flingVelocity(gesture.y1 - gesture.y0, dt);
        const current = toolRef.current;
        if (current === "meteor") sim.throwMeteor(gesture.x0, gesture.y0, vx, vy);
        else if (isKind(current)) sim.spawnAt(current, gesture.x0, gesture.y0, vx, vy);
      }
      if (gesture.type === "pinch" && pointers.size < 2) gesture = null;
      else if (gesture.type !== "pinch") gesture = null;
      if (!gesture) arrow.current = null;
      canvas.style.cursor = "default";
    };

    const onWheel = (event: WheelEvent) => {
      if (visitRef.current) return;
      event.preventDefault();
      const p = local(event as unknown as PointerEvent);
      const factor = Math.exp(-event.deltaY * 0.0011);
      sim.zoomAt(p.x, p.y, cssSize.w, cssSize.h, factor);
    };

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      sim.frame(dt);
      sim.recordTrails();
      if (sim.sfx) {
        score.enabled = soundRef.current;
        score.play(sim.sfx);
        sim.sfx = null;
      }
      render(ctx, sim, cssSize.w, cssSize.h, now / 1000, {
        hoverId: hover.id,
        arrow: arrow.current,
        visit: visitRef.current,
      });
      raf = requestAnimationFrame(loop);
    };

    canvas.addEventListener("pointerdown", onDown);
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerup", onUp);
    canvas.addEventListener("pointercancel", onUp);
    canvas.addEventListener("contextmenu", (event) => event.preventDefault());
    canvas.addEventListener("wheel", onWheel, { passive: false });
    raf = requestAnimationFrame(loop);
    const poll = window.setInterval(() => setHud(readHud(sim)), 200);
    setHasSave(Boolean(window.localStorage.getItem(SAVE_KEY)));

    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(poll);
      observer.disconnect();
      canvas.removeEventListener("pointerdown", onDown);
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerup", onUp);
      canvas.removeEventListener("pointercancel", onUp);
      canvas.removeEventListener("wheel", onWheel);
    };
  }, []);

  soundRef.current = soundOn;

  useEffect(() => {
    return () => musicRef.current?.stop();
  }, []);

  const toggleMusic = async () => {
    if (!musicRef.current) musicRef.current = new AmbientMusic();
    if (musicOn) {
      musicRef.current.stop();
      setMusicOn(false);
    } else {
      try {
        await musicRef.current.start();
        setMusicOn(true);
      } catch {
        setToast("O navegador não conseguiu iniciar a música. Toque novamente para tentar.");
      }
    }
  };

  useEffect(() => {
    if (!hud.notice) return;
    setToast(hud.notice);
    const id = window.setTimeout(() => setToast(""), 3800);
    return () => window.clearTimeout(id);
  }, [hud.notice]);

  useEffect(() => {
    const sim = simRef.current!;
    const onKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement) return;
      if (event.code === "Space") {
        sim.paused = !sim.paused;
        event.preventDefault();
      } else if (event.key === "Escape") {
        setVisit(null);
        sim.paused = false;
        sim.selectedId = null;
      } else if (event.key === "f") {
        const rect = wrapRef.current?.getBoundingClientRect();
        if (rect) sim.fit(rect.width, rect.height, "all");
      } else if ((event.key === "Delete" || event.key === "Backspace") && sim.selectedId != null) {
        sim.remove(sim.selectedId);
      } else if (event.key === "[") sim.timescale = clampRate(sim.timescale / 2);
      else if (event.key === "]") sim.timescale = clampRate(sim.timescale * 2);
      else if (event.key === "1") setTool("move");
      else if (event.key === "2") setTool("meteor");
      else if (event.key === "3") setTool("erase");
      else if (event.key === "4") setTool("explode");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const sim = simRef.current!;
  const showBody = Boolean(hud.selected) && !preferCatalog;

  const fit = (mode: "inner" | "jupiter" | "all") => {
    const rect = wrapRef.current?.getBoundingClientRect();
    if (rect) sim.fit(rect.width, rect.height, mode);
    setHud(readHud(sim));
  };

  const loadPreset = (preset: PresetName) => {
    sim.load(preset);
    const rect = wrapRef.current?.getBoundingClientRect();
    if (rect) sim.fit(rect.width, rect.height, preset === "solar" || preset === "fall" ? "inner" : "all");
    setVisit(null);
    setPreferCatalog(false);
    setSheet(null);
    setHud(readHud(sim));
  };

  const openVisit = (entry: CatalogEntry) => {
    sim.paused = true;
    setVisit(entry);
    setSheet(null);
    setHud(readHud(sim));
  };

  const closeVisit = () => {
    sim.paused = false;
    setVisit(null);
    setHud(readHud(sim));
  };

  const placeSun = (entry: CatalogEntry, realMass: boolean) => {
    if (realMass) sim.setMassMode("real");
    sim.replaceAnchor(entry, false);
    sim.paused = false;
    setVisit(null);
    setPreferCatalog(false);
    const rect = wrapRef.current?.getBoundingClientRect();
    if (rect) sim.fit(rect.width, rect.height, realMass ? "jupiter" : "inner");
    setHud(readHud(sim));
  };

  const refresh = () => setHud(readHud(sim));

  return (
    <div className="stage" ref={wrapRef}>
      {language === null && (
        <div className="language-gate" role="dialog" aria-modal="true" aria-labelledby="language-title">
          <div className="language-card">
            <div className="language-orb" aria-hidden="true">✦</div>
            <p className="language-eyebrow">SIDERRA: BEYOND THE STARS</p>
            <h1 id="language-title">Choose your language</h1>
            <p className="language-subtitle">Escolha seu idioma · Elige tu idioma</p>
            <div className="language-options">
              <button type="button" className="language-option" onClick={() => { setLanguage("pt"); try { window.localStorage.setItem(LANGUAGE_KEY, "pt"); } catch {} }}>🇧🇷 <span><strong>Português</strong><small>Brasil</small></span><span className="language-arrow">→</span></button>
              <button type="button" className="language-option" onClick={() => { setLanguage("en"); try { window.localStorage.setItem(LANGUAGE_KEY, "en"); } catch {} }}>🇺🇸 <span><strong>English</strong><small>Worldwide</small></span><span className="language-arrow">→</span></button>
              <button type="button" className="language-option" onClick={() => { setLanguage("es"); try { window.localStorage.setItem(LANGUAGE_KEY, "es"); } catch {} }}>🇪🇸 <span><strong>Español</strong><small>Internacional</small></span><span className="language-arrow">→</span></button>
            </div>
            <p className="language-footnote">Your choice will be saved on this device.</p>
          </div>
        </div>
      )}
      <canvas ref={canvasRef} aria-label="Laboratório gravitacional Siderra" />
      <div className="chrome">
        <header className="topbar">
          <div className="brand">
            <h1>Siderra</h1>
            <p>Laboratório gravitacional</p>
          </div>
          <div className="cluster">
            <button type="button" className="btn icon-btn" aria-label={musicOn ? "Desligar música ambiente" : "Ligar música ambiente"} aria-pressed={musicOn} title={musicOn ? "Música ambiente ligada" : "Música ambiente desligada"} onClick={() => void toggleMusic()}>
              <Music size={16} />
            </button>
            <button type="button" className="btn icon-btn" aria-label={hud.paused ? "Continuar" : "Pausar"} onClick={() => { sim.paused = !sim.paused; refresh(); }}>
              {hud.paused ? <Play size={16} /> : <Pause size={16} />}
            </button>
            <button type="button" className="btn icon-btn" aria-label="Desacelerar" onClick={() => { sim.timescale = clampRate(sim.timescale / 2); refresh(); }}>
              <Minus size={16} />
            </button>
            <span className="stat">{hud.paused ? "pausa" : formatRate(hud.rate)}</span>
            <button type="button" className="btn icon-btn" aria-label="Acelerar" onClick={() => { sim.timescale = clampRate(sim.timescale * 2); refresh(); }}>
              <Plus size={16} />
            </button>
            <span className="stat">{hud.count} corpos</span>
            <span className="stat">{formatDays(hud.time)}</span>
          </div>
        </header>

        <aside className="tools panel">
          <h2>Mãos</h2>
          <p className="hint">Arraste um corpo. No vazio, a tela se move. A roda aproxima.</p>
          <div className="tool-grid">
            <ToolButton icon={Move} label="Mover" pressed={tool === "move"} onClick={() => setTool("move")} />
            <ToolButton icon={Rocket} label="Meteoro" pressed={tool === "meteor"} onClick={() => setTool("meteor")} />
            <ToolButton icon={Trash2} label="Apagar" pressed={tool === "erase"} onClick={() => setTool("erase")} />
            <ToolButton icon={Flame} label="Explodir" pressed={tool === "explode"} onClick={() => setTool("explode")} />
          </div>
          <div className="section-label">Criar e lançar</div>
          <div className="tool-grid">
            {CREATE.map((item) => (
              <ToolButton key={item.id} icon={item.icon} label={item.label} pressed={tool === item.id} onClick={() => setTool(item.id)} />
            ))}
          </div>
          <div className="section-label">Cenas</div>
          <div className="tool-grid">
            {PRESETS.map((item) => (
              <button key={item.id} type="button" className="btn btn-quiet" onClick={() => loadPreset(item.id)}>
                {item.label}
              </button>
            ))}
          </div>
          <div className="row-actions">
            <button type="button" className="btn btn-quiet" onClick={() => fit("inner")}>Internos</button>
            <button type="button" className="btn btn-quiet" onClick={() => fit("jupiter")}>Júpiter</button>
            <button type="button" className="btn btn-quiet" onClick={() => fit("all")}>
              <Maximize2 size={14} /> Tudo
            </button>
          </div>
        </aside>

        {!visit ? (
        <aside className="dock panel">
          {showBody && hud.selected ? (
            <BodyDock
              hud={hud}
              onCatalog={() => setPreferCatalog(true)}
              onChange={() => refresh()}
              sim={sim}
            />
          ) : (
            <CatalogDock onOpen={openVisit} />
          )}
          <Options
            hud={hud}
            sim={sim}
            soundOn={soundOn}
            hasSave={hasSave}
            onSound={(value) => setSoundOn(value)}
            onSaved={() => setHasSave(true)}
            onChange={() => refresh()}
          />
        </aside>
        ) : null}

        {visit ? (
          <section className="visit-card panel" aria-label={`Visita a ${visit.name}`}>
            <h2>{visit.name}</h2>
            <p className="hint">{visit.kindLabel}</p>
            <p className="note" style={{ marginTop: 0 }}>{visit.distance}</p>
            <p className="note">{visit.fact}</p>
            <p className="note">{horizonCaption(visit)}</p>
            <div className="row-actions">
              <button type="button" className="btn btn-primary" onClick={() => placeSun(visit, false)}>
                Pôr no lugar do Sol
              </button>
              <button type="button" className="btn" onClick={() => placeSun(visit, true)}>
                Com massa real
              </button>
              <button
                type="button"
                className="btn"
                onClick={() => {
                  sim.dropCatalog(visit, sim.camera.x + 1.4, sim.camera.y + 0.6);
                  closeVisit();
                }}
              >
                Soltar no atelier
              </button>
              <button type="button" className="btn btn-quiet" onClick={closeVisit}>
                Voltar
              </button>
            </div>
          </section>
        ) : null}

        {sheet ? (
          <section className="panel sheet-open" aria-label="Painel">
            <div className="row-actions" style={{ marginTop: 0 }}>
              <button type="button" className="btn icon-btn" aria-label="Fechar" onClick={() => setSheet(null)}>
                <X size={16} />
              </button>
            </div>
            {sheet === "create" ? (
              <>
                <h2>Criar</h2>
                <p className="hint">Toque e arraste para dar velocidade.</p>
                <div className="tool-grid">
                  {CREATE.map((item) => (
                    <ToolButton
                      key={item.id}
                      icon={item.icon}
                      label={item.label}
                      pressed={tool === item.id}
                      onClick={() => {
                        setTool(item.id);
                        setSheet(null);
                      }}
                    />
                  ))}
                </div>
              </>
            ) : null}
            {sheet === "catalog" ? <CatalogDock onOpen={openVisit} /> : null}
            {sheet === "body" && hud.selected ? (
              <BodyDock hud={hud} sim={sim} onCatalog={() => setSheet("catalog")} onChange={refresh} />
            ) : null}
            {sheet === "more" ? (
              <>
                <h2>Cena</h2>
                <div className="tool-grid">
                  {PRESETS.map((item) => (
                    <button key={item.id} type="button" className="btn btn-quiet" onClick={() => loadPreset(item.id)}>
                      {item.label}
                    </button>
                  ))}
                </div>
                <div className="section-label">Universo</div>
                <div className="tool-grid">
                  <button type="button" className="btn btn-quiet" aria-pressed={sim.nebulae} onClick={() => { sim.nebulae = !sim.nebulae; refresh(); }}>{sim.nebulae ? "Nebulosas: ligadas" : "Nebulosas: desligadas"}</button>
                  <button type="button" className="btn btn-quiet" onClick={() => { sim.triggerCosmicEvent(); refresh(); }}>Supernova / evento</button>
                  <button type="button" className="btn btn-quiet" onClick={() => { sim.meteorShower(); refresh(); }}>Chuva de meteoros</button>
                  <button type="button" className="btn btn-quiet" onClick={() => { loadPreset("fictional"); }}>Sistema fictício</button>
                  <button type="button" className="btn btn-quiet" onClick={() => fit("all")}>Mapa · ver tudo</button>
                </div>
                <p className="hint" style={{ marginTop: 10 }}>Eventos são efeitos de simulação, não previsões astronômicas. O sistema Asterion é fictício.</p>
                <div className="section-label">Mapa navegável · tocar para focar</div>
                <div className="tool-grid">
                  {sim.bodies.map((body) => (
                    <button key={body.id} type="button" className="btn btn-quiet" onClick={() => { sim.selectedId = body.id; sim.camera.x = body.x; sim.camera.y = body.y; setPreferCatalog(false); refresh(); }}>
                      {body.name}
                    </button>
                  ))}
                </div>
                <div className="row-actions">
                  <button type="button" className="btn" onClick={() => fit("inner")}>Internos</button>
                  <button type="button" className="btn" onClick={() => fit("jupiter")}>Júpiter</button>
                  <button type="button" className="btn" onClick={() => fit("all")}>Tudo</button>
                </div>
                <Options hud={hud} sim={sim} soundOn={soundOn} hasSave={hasSave} onSound={setSoundOn} onSaved={() => setHasSave(true)} onChange={refresh} />
              </>
            ) : null}
          </section>
        ) : null}

        <nav className="mobile-bar" aria-label="Ferramentas">
          <ToolButton icon={Move} label="Mover" pressed={tool === "move"} onClick={() => { setTool("move"); setSheet(null); }} />
          <ToolButton icon={Rocket} label="Meteoro" pressed={tool === "meteor"} onClick={() => { setTool("meteor"); setSheet(null); }} />
          <ToolButton icon={Trash2} label="Apagar" pressed={tool === "erase"} onClick={() => { setTool("erase"); setSheet(null); }} />
          <ToolButton icon={Flame} label="Explodir" pressed={tool === "explode"} onClick={() => { setTool("explode"); setSheet(null); }} />
          <button type="button" className="btn" onClick={() => setSheet(sheet === "create" ? null : "create")}>Criar</button>
          <button type="button" className="btn" onClick={() => setSheet(sheet === "catalog" ? null : "catalog")}>
            <BookOpen size={16} /> Reais
          </button>
          {hud.selected ? (
            <button type="button" className="btn" onClick={() => setSheet(sheet === "body" ? null : "body")}>{hud.selected.name}</button>
          ) : null}
          <button type="button" className="btn" onClick={() => setSheet(sheet === "more" ? null : "more")}>Cena</button>
        </nav>

        {toast && !visit ? <div className="toast">{toast}</div> : null}
      </div>
    </div>
  );
}

function ToolButton({
  icon: Icon,
  label,
  pressed,
  onClick,
}: {
  icon: typeof Sun;
  label: string;
  pressed?: boolean;
  onClick: () => void;
}) {
  return (
    <button type="button" className="btn" aria-pressed={pressed ? "true" : "false"} onClick={onClick}>
      <Icon size={16} />
      {label}
    </button>
  );
}

function CatalogDock({ onOpen }: { onOpen: (entry: CatalogEntry) => void }) {
  const groups = [
    { key: "star", title: "Estrelas", entries: CATALOG.filter((entry) => entry.category === "star") },
    { key: "neutron", title: "Estrelas de nêutrons", entries: CATALOG.filter((entry) => entry.category === "neutron") },
    { key: "black-hole", title: "Buracos negros", entries: CATALOG.filter((entry) => entry.category === "black-hole") },
  ];
  return (
    <>
      <h2>Catálogo de objetos reais</h2>
      <p className="hint">Explore objetos astronômicos conhecidos por categoria. Escolha um para ver seus detalhes e levá-lo ao atelier.</p>
      {groups.map((group) => (
        <section key={group.key} className="catalog-group">
          <h3>{group.title} <span>{group.entries.length}</span></h3>
          <div className="catalog-list">
            {group.entries.map((entry) => (
              <button key={entry.id} type="button" className="catalog-item" onClick={() => onOpen(entry)}>
                <strong>{entry.name}</strong>
                <span>{formatMass(entry.mass)} · {entry.kindLabel}</span>
                <small>{entry.distance}</small>
              </button>
            ))}
          </div>
        </section>
      ))}
    </>
  );
}

function BodyDock({
  hud,
  sim,
  onCatalog,
  onChange,
}: {
  hud: Hud;
  sim: Simulation;
  onCatalog: () => void;
  onChange: () => void;
}) {
  const body = hud.selected;
  if (!body) return null;
  return (
    <>
      <h2>{body.name}</h2>
      <p className="hint">{KIND_LABEL[body.kind]}</p>
      <p className="note" style={{ marginTop: 0 }}>
        Massa real {formatMass(body.mass)} · gravidade {formatMass(sim.body(body.id)?.gravMass ?? body.mass)} · {formatAU(body.dist)} do centro · {body.speed.toFixed(3).replace(".", ",")} UA/dia
      </p>
      {body.note ? <p className="note">{body.note}</p> : null}
      <div className="section-label">Ficha científica</div>
      <div className="temperature-card" aria-label="Temperatura atual">
        <div className="temperature-heading"><span aria-hidden="true">🌡️</span> Temperatura atual</div>
        <strong>{formatTemperature(estimateTemperature(sim, body.id))}</strong>
        <p className="note">Estimativa do modelo, atualizada conforme a posição e o tipo do objeto.</p>
      </div>
      <div className="note" style={{ marginTop: 0 }}>
        <div>Classe: {KIND_LABEL[body.kind]}</div>
        <div>Velocidade orbital: {body.speed.toFixed(4).replace(".", ",")} UA/dia</div>
        <div>Distância do centro da cena: {formatAU(body.dist)}</div>
        <div>Estado: {body.pinned ? "fixado" : "dinâmico"} · gravidade {sim.gravity ? "ativa" : "pausada"}</div>
        <div>Dados de massa e distância são valores do modelo da simulação.</div>
      </div>
      {(["star", "white-dwarf", "neutron", "black-hole"] as Kind[]).includes(body.kind) ? (
        <button type="button" className="btn btn-quiet" onClick={() => { sim.evolveSelectedStar(); onChange(); }}>Avançar evolução estelar</button>
      ) : null}
      <div className="field">
        <label>
          Massa real
          <span>{formatMass(body.mass)}</span>
        </label>
        <input
          type="range"
          min={-10}
          max={Math.log10(200_000_000_000)}
          step={0.05}
          value={Math.log10(Math.min(200_000_000_000, Math.max(1e-10, body.mass)))}
          onChange={(event) => {
            sim.setTrueMass(body.id, 10 ** Number(event.target.value));
            onChange();
          }}
          aria-label="Massa real"
        />
      </div>
      <div className="field">
        <label>
          Raio de encontro
          <span>{formatAU(body.radius)}</span>
        </label>
        <input
          type="range"
          min={0.03}
          max={1.6}
          step={0.01}
          value={Math.min(1.6, body.radius)}
          onChange={(event) => {
            const live = sim.body(body.id);
            if (live) live.radius = Number(event.target.value);
            onChange();
          }}
          aria-label="Raio de encontro"
        />
      </div>
      <div className="row-actions">
        <button type="button" className="btn" onClick={() => { sim.togglePin(body.id); onChange(); }}>
          {body.pinned ? <PinOff size={16} /> : <Pin size={16} />}
          {body.pinned ? "Soltar" : "Fixar"}
        </button>
        <button type="button" className="btn" onClick={() => { sim.explode(body.id); onChange(); }}>
          <Flame size={16} /> Explodir
        </button>
        <button type="button" className="btn" onClick={() => { sim.duplicate(body.id); onChange(); }}>
          <Copy size={16} /> Duplicar
        </button>
        <button type="button" className="btn" onClick={() => { sim.remove(body.id); onChange(); }}>
          <Trash2 size={16} /> Apagar
        </button>
        {body.kind === "black-hole" ? (
          <button type="button" className="btn" onClick={() => { sim.applyRealHorizon(body.id); onChange(); const rect = document.querySelector(".stage")?.getBoundingClientRect(); if (rect) sim.fit(rect.width, rect.height, "all"); }}>
            Horizonte real
          </button>
        ) : (
          <button
            type="button"
            className="btn"
            onClick={() => {
              const live = sim.body(body.id);
              if (!live) return;
              live.kind = "black-hole";
              live.skin = "hole";
              live.rings = false;
              if (live.mass < 3) live.mass = 8;
              live.gravMass = sim.massOf(live.mass);
              onChange();
            }}
          >
            <Eclipse size={16} /> Virar buraco
          </button>
        )}
        <button type="button" className="btn btn-quiet" onClick={onCatalog}>
          Catálogo
        </button>
      </div>
    </>
  );
}

function Options({
  hud,
  sim,
  soundOn,
  hasSave,
  onSound,
  onSaved,
  onChange,
}: {
  hud: Hud;
  sim: Simulation;
  soundOn: boolean;
  hasSave: boolean;
  onSound: (value: boolean) => void;
  onSaved: () => void;
  onChange: () => void;
}) {
  return (
    <>
      <div className="section-label">Física</div>
      <div className="tool-grid">
        <button type="button" className="btn" aria-pressed={hud.massMode === "play"} onClick={() => { sim.setMassMode("play"); onChange(); }}>
          Observável
        </button>
        <button type="button" className="btn" aria-pressed={hud.massMode === "real"} onClick={() => { sim.setMassMode("real"); onChange(); }}>
          Massa real
        </button>
        <button type="button" className="btn" aria-pressed={hud.gravity} onClick={() => { sim.gravity = !sim.gravity; onChange(); }}>
          Gravidade
        </button>
        <button type="button" className="btn" aria-pressed={hud.collisions} onClick={() => { sim.collisions = !sim.collisions; onChange(); }}>
          Colisões
        </button>
        <button type="button" className="btn" aria-pressed={hud.trails} onClick={() => { sim.trails = !sim.trails; if (!sim.trails) for (const body of sim.bodies) body.trail = []; onChange(); }}>
          Rastros
        </button>
        <button type="button" className="btn" aria-pressed={hud.guides} onClick={() => { sim.guides = !sim.guides; onChange(); }}>
          Órbitas
        </button>
        <button type="button" className="btn" aria-pressed={soundOn} onClick={() => onSound(!soundOn)}>
          Som
        </button>
        <button
          type="button"
          className="btn"
          onClick={() => {
            window.localStorage.setItem(SAVE_KEY, sim.toJSON());
            sim.notice = "Cena guardada neste navegador.";
            onSaved();
            onChange();
          }}
        >
          Guardar
        </button>
        {hasSave ? (
          <button
            type="button"
            className="btn"
            onClick={() => {
              const raw = window.localStorage.getItem(SAVE_KEY);
              if (raw) sim.fromJSON(raw);
              onChange();
            }}
          >
            Abrir
          </button>
        ) : null}
      </div>
      <p className="note">Tamanhos ampliados para a mão. Planetas usam massa real. Buracos negros enormes, por padrão, usam gravidade comprimida.</p>
    </>
  );
}

function formatTemperature(celsius: number): string {
  if (!Number.isFinite(celsius)) return "Indisponível";
  return `${Math.round(celsius).toLocaleString("pt-BR")} °C`;
}

/** Approximate temperatures for gameplay, not a full climate/stellar-atmosphere simulation. */
function estimateTemperature(sim: Simulation, id: number): number {
  const body = sim.body(id);
  if (!body) return Number.NaN;

  if (body.kind === "star") {
    // Rough mass-to-surface-temperature mapping for main-sequence stars.
    const solarMass = Math.max(0.08, body.mass);
    return Math.max(2_400, Math.min(42_000, 5_778 * Math.pow(solarMass, 0.45))) - 273.15;
  }
  if (body.kind === "white-dwarf") return 8_000 - 273.15;
  if (body.kind === "neutron") return 600_000 - 273.15;
  if (body.kind === "black-hole") {
    // Hawking temperature for a non-rotating black hole, mass expressed in solar masses.
    const massKg = Math.max(1e-10, body.mass) * 1.98847e30;
    return (1.227e23 / massKg) - 273.15;
  }

  const stars = sim.bodies.filter((candidate) => candidate.alive && candidate.kind === "star");
  if (!stars.length) return -270;
  let received = 0;
  for (const star of stars) {
    const distance = Math.max(0.05, Math.hypot(body.x - star.x, body.y - star.y));
    const mass = Math.max(0.08, star.mass);
    const luminosity = Math.pow(mass, 3.5);
    received += luminosity / (distance * distance);
  }
  // Game orbit distances are not expressed in AU: in the Solar preset Earth is
  // at 2.15 units. Normalize to that reference so Earth-like planets around a
  // Sun-like star land near a realistic global mean instead of deep-freezing.
  const referenceDistance = 2.15;
  const normalizedReceived = received * referenceDistance * referenceDistance;
  const kelvin = 278 * Math.pow(Math.max(1e-8, normalizedReceived), 0.25);
  const greenhouse = body.kind === "gas" ? 20 : body.kind === "planet" ? 10 : 0;
  return kelvin - 273.15 + greenhouse;
}

function isKind(tool: SpawnTool): tool is Kind {
  return tool !== "move" && tool !== "meteor" && tool !== "erase" && tool !== "explode";
}

function clampRate(value: number): number {
  return Math.max(0.25, Math.min(8000, value));
}
