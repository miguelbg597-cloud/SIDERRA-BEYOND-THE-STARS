import type { CatalogEntry } from "@/game/catalog";
import type { Simulation } from "@/game/sim";
import type { Body } from "@/game/types";
import { schwarzschildAU } from "@/game/units";

type StarDot = { x: number; y: number; z: number; s: number; a: number };

const FIELD: StarDot[] = Array.from({ length: 320 }, (_, i) => {
  const n = mulberry(i + 1);
  return {
    x: n(),
    y: n(),
    z: 0.2 + n() * 0.8,
    s: n() > 0.92 ? 1.6 : 0.7 + n(),
    a: 0.2 + n() * 0.65,
  };
});

export type DrawHints = {
  hoverId: number | null;
  arrow: { x0: number; y0: number; x1: number; y1: number } | null;
  visit: CatalogEntry | null;
};

export function render(ctx: CanvasRenderingContext2D, sim: Simulation, width: number, height: number, now: number, hints: DrawHints): void {
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#07080c";
  ctx.fillRect(0, 0, width, height);
  drawField(ctx, sim, width, height);
  if (sim.nebulae) drawNebulae(ctx, width, height, now);
  if (hints.visit) {
    drawVisit(ctx, width, height, hints.visit, now);
    return;
  }

  ctx.save();
  if (sim.shake > 0.2) {
    const mag = sim.shake;
    ctx.translate((mulberry(Math.floor(now * 40))() - 0.5) * mag, (mulberry(Math.floor(now * 40) + 3)() - 0.5) * mag);
  }

  const { k } = sim.camera;
  if (sim.guides) drawGuides(ctx, sim, width, height);
  drawTrails(ctx, sim, width, height);

  const ordered = [...sim.bodies].sort((a, b) => a.radius - b.radius);
  for (const body of ordered) drawBody(ctx, sim, body, width, height, now);

  // Supernovae get a spectacular, short-lived screen-space flash plus a huge local corona.
  if (sim.supernovaFlash) {
    const flash = sim.supernovaFlash;
    const p = sim.worldToScreen(flash.x, flash.y, width, height);
    const u = Math.min(1, flash.age / flash.dur);
    const peak = Math.max(0, 1 - flash.age / 0.72);
    const radius = Math.max(width, height) * (0.12 + u * 0.72);
    const corona = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, radius);
    corona.addColorStop(0, `rgba(255,255,255,${0.98 * Math.max(peak, 0.12 * (1-u))})`);
    corona.addColorStop(0.08, `rgba(255,247,205,${0.92 * Math.max(peak, 0.08 * (1-u))})`);
    corona.addColorStop(0.28, `rgba(255,150,75,${0.48 * (1-u)})`);
    corona.addColorStop(1, "rgba(255,80,35,0)");
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.fillStyle = corona;
    ctx.fillRect(0, 0, width, height);
    if (peak > 0.05) {
      ctx.fillStyle = `rgba(255,255,245,${peak * 0.48})`;
      ctx.fillRect(0, 0, width, height);
    }
    ctx.restore();
  }

  for (const shock of sim.shocks) {
    const p = sim.worldToScreen(shock.x, shock.y, width, height);
    const u = shock.age / shock.dur;
    const r = shock.radius * k * (0.25 + u);
    ctx.beginPath();
    ctx.arc(p.x, p.y, Math.max(1, r), 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(244, 236, 224, ${0.45 * (1 - u)})`;
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }

  for (const particle of sim.particles) {
    const p = sim.worldToScreen(particle.x, particle.y, width, height);
    const alpha = Math.max(0, particle.life / particle.max);
    ctx.fillStyle = hexAlpha(particle.color, Math.min(1, alpha * 1.35));
    ctx.beginPath();
    ctx.arc(p.x, p.y, Math.max(1.2, particle.size * k * 1.35), 0, Math.PI * 2);
    ctx.fill();
  }

  if (hints.arrow) {
    const a = sim.worldToScreen(hints.arrow.x0, hints.arrow.y0, width, height);
    const b = sim.worldToScreen(hints.arrow.x1, hints.arrow.y1, width, height);
    drawArrow(ctx, a.x, a.y, b.x, b.y);
  }

  for (const body of sim.bodies) {
    const screenR = body.radius * k;
    const show = body.id === sim.selectedId || body.id === hints.hoverId || body.anchor || body.kind === "black-hole" || screenR > 16;
    if (!show) continue;
    const p = sim.worldToScreen(body.x, body.y, width, height);
    drawLabel(ctx, body.name, p.x, p.y - Math.max(screenR, 8) - 10, body.id === sim.selectedId);
  }

  ctx.restore();
}

function drawNebulae(ctx: CanvasRenderingContext2D, width: number, height: number, now: number): void {
  // Soft, slow-moving pixel-friendly nebula glows; intentionally decorative, not physical gas simulation.
  const clouds = [
    { x: 0.18, y: 0.27, r: 0.22, c: "rgba(64, 75, 190, 0.11)" },
    { x: 0.78, y: 0.23, r: 0.25, c: "rgba(133, 45, 157, 0.10)" },
    { x: 0.61, y: 0.79, r: 0.24, c: "rgba(26, 123, 160, 0.09)" },
  ];
  for (let i = 0; i < clouds.length; i++) {
    const cloud = clouds[i]!;
    const x = width * cloud.x + Math.sin(now * 0.025 + i) * 9;
    const y = height * cloud.y + Math.cos(now * 0.02 + i * 2) * 7;
    const radius = Math.max(width, height) * cloud.r;
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, cloud.c);
    gradient.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = gradient;
    ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  }
}

function drawField(ctx: CanvasRenderingContext2D, sim: Simulation, width: number, height: number): void {
  const parallax = sim.camera.k * 0.015;
  for (const star of FIELD) {
    const x = (((star.x * width + sim.camera.x * parallax * star.z) % width) + width) % width;
    const y = (((star.y * height + sim.camera.y * parallax * star.z) % height) + height) % height;
    ctx.fillStyle = `rgba(232, 234, 240, ${star.a})`;
    ctx.fillRect(x, y, star.s, star.s);
  }
}

function drawGuides(ctx: CanvasRenderingContext2D, sim: Simulation, width: number, height: number): void {
  const anchor = sim.anchor();
  if (!anchor) return;
  const origin = sim.worldToScreen(anchor.x, anchor.y, width, height);
  ctx.lineWidth = 1;
  for (const body of sim.bodies) {
    if (!body.orbitA) continue;
    ctx.beginPath();
    ctx.arc(origin.x, origin.y, body.orbitA * sim.camera.k, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(244,244,245,0.13)";
    ctx.stroke();
  }
}

function drawTrails(ctx: CanvasRenderingContext2D, sim: Simulation, width: number, height: number): void {
  if (!sim.trails) return;
  for (const body of sim.bodies) {
    if (body.trail.length < 2) continue;
    ctx.beginPath();
    const first = sim.worldToScreen(body.trail[0]!.x, body.trail[0]!.y, width, height);
    ctx.moveTo(first.x, first.y);
    for (let i = 1; i < body.trail.length; i++) {
      const p = sim.worldToScreen(body.trail[i]!.x, body.trail[i]!.y, width, height);
      ctx.lineTo(p.x, p.y);
    }
    ctx.strokeStyle = hexAlpha(body.kind === "black-hole" ? "#f0d2b4" : body.color, 0.45);
    ctx.lineWidth = Math.max(1, Math.min(2.2, body.radius * sim.camera.k * 0.12));
    ctx.stroke();
  }
}

function drawBody(ctx: CanvasRenderingContext2D, sim: Simulation, body: Body, width: number, height: number, now: number): void {
  const p = sim.worldToScreen(body.x, body.y, width, height);
  const r = Math.max(body.radius * sim.camera.k, body.kind === "black-hole" ? 7 : 3.2);
  if (body.rings) drawRings(ctx, p.x, p.y, r, false);
  if (body.skin === "hole" || body.kind === "black-hole") drawHole(ctx, p.x, p.y, r, now, body.id, body.mass);
  else if (body.skin === "star") drawStar(ctx, p.x, p.y, r, body.color, now, body.id);
  else if (body.skin === "comet" || body.kind === "comet") drawComet(ctx, sim, body, p.x, p.y, r);
  else if (body.kind === "neutron") drawNeutronPixel(ctx, p.x, p.y, r, body.color, now, body.id);
  else if (body.kind === "white-dwarf") drawWhiteDwarfPixel(ctx, p.x, p.y, r, body.color, now, body.id);
  else if (body.skin === "compact") drawCompact(ctx, p.x, p.y, r, body.color);
  else drawPlanet(ctx, p.x, p.y, r, body, now);
  if (body.rings) drawRings(ctx, p.x, p.y, r, true);
  if (body.id === sim.selectedId) {
    ctx.beginPath();
    ctx.arc(p.x, p.y, r + 7, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(244,244,245,0.85)";
    ctx.lineWidth = 1.25;
    ctx.stroke();
  }
}

function drawStar(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string, now: number, id: number): void {
  // Pixel-art star: stepped glow, blocky corona and a dithered square-grid surface.
  const glow = ctx.createRadialGradient(x, y, r * 0.35, x, y, r * 4.2);
  glow.addColorStop(0, hexAlpha(color, 0.48));
  glow.addColorStop(1, hexAlpha(color, 0));
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(x, y, r * 4.2, 0, Math.PI * 2);
  ctx.fill();

  const cell = Math.max(2, Math.ceil(r / 7));
  const cells = Math.max(8, Math.ceil((r * 2) / cell));
  const seed = id * 421 + 17;
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  for (let iy = -cells; iy <= cells; iy++) {
    for (let ix = -cells; ix <= cells; ix++) {
      const nx = (ix + 0.5) / cells;
      const ny = (iy + 0.5) / cells;
      const d = nx * nx + ny * ny;
      if (d > 1) continue;
      const rnd = mulberry(seed + ix * 9211 + iy * 7727)();
      let shade = color;
      if (d < 0.22) shade = rnd > 0.18 ? "#fff7b8" : "#ffe46a";
      else if (d < 0.55) shade = rnd > 0.42 ? "#ffb52e" : color;
      else shade = rnd > 0.48 ? "#f05a24" : mix(color, "#7b182b", 0.45);
      if (rnd > 0.94) shade = "#fff4d1";
      ctx.fillStyle = shade;
      ctx.fillRect(x + ix * cell, y + iy * cell, cell + 0.3, cell + 0.3);
    }
  }
  // Chunky animated corona rays.
  ctx.fillStyle = "#ffb52e";
  for (let i = 0; i < 12; i++) {
    const a = (i * Math.PI) / 6 + now * 0.035 + id * 0.1;
    const len = r * (1.25 + 0.18 * Math.sin(now * 0.7 + i));
    const bx = x + Math.cos(a) * len;
    const by = y + Math.sin(a) * len;
    const size = Math.max(2, cell * 0.72);
    ctx.fillRect(Math.round(bx / size) * size, Math.round(by / size) * size, size, size);
  }
  ctx.restore();
}

function drawHole(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, now: number, id: number, mass: number): void {
  // Supermassive black holes (>= one million solar masses) get a quasar-like
  // accretion disk and long bipolar jets. Stellar-mass holes remain subtler.
  const supermassive = mass >= 1e6;
  const diskR = r * (supermassive ? 4.2 : 2.25);
  const diskH = Math.max(r * (supermassive ? 1.12 : 0.68), 4);
  const cell = Math.max(2, Math.ceil(r / 7));
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-0.48 + Math.sin(id) * 0.04);

  const halo = ctx.createRadialGradient(0, 0, r * 0.7, 0, 0, diskR * 1.5);
  halo.addColorStop(0, supermassive ? "rgba(80,170,255,0.30)" : "rgba(255,110,28,0.18)");
  halo.addColorStop(1, supermassive ? "rgba(70,120,255,0)" : "rgba(255,60,20,0)");
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.ellipse(0, 0, diskR * 1.35, diskH * 1.5, 0, 0, Math.PI * 2);
  ctx.fill();

  // Outer burgundy disk made from square pixels.
  for (let iy = -Math.ceil(diskH / cell); iy <= Math.ceil(diskH / cell); iy++) {
    for (let ix = -Math.ceil(diskR / cell); ix <= Math.ceil(diskR / cell); ix++) {
      const nx = ix * cell / diskR;
      const ny = iy * cell / diskH;
      const d = nx * nx + ny * ny;
      if (d > 1 || d < 0.10) continue;
      const wave = Math.sin(ix * 0.8 + now * 0.7 + id) + Math.cos(iy * 1.7 - now * 0.45);
      let c = supermassive ? "#172c67" : "#401329";
      if (d < 0.78) c = supermassive
        ? (wave > 0.5 ? "#3276d5" : "#24469b")
        : (wave > 0.5 ? "#a51e35" : "#6e1830");
      if (d < 0.58) c = supermassive
        ? (wave > -0.15 ? "#51b9ff" : "#3b78ec")
        : (wave > -0.15 ? "#e83e22" : "#b52b23");
      if (d < 0.38) c = supermassive
        ? (wave > 0.25 ? "#b8f4ff" : "#6bd7ff")
        : (wave > 0.25 ? "#ff6b16" : "#f34a12");
      if (d < 0.22) c = supermassive
        ? (wave > -0.1 ? "#ffffff" : "#b9f5ff")
        : (wave > -0.1 ? "#ffd43b" : "#ff9d1c");
      if (d < 0.14) c = "#ffffff";
      ctx.fillStyle = c;
      ctx.fillRect(ix * cell, iy * cell, cell + 0.5, cell + 0.5);
    }
  }

  // Bright, layered bipolar relativistic jets for supermassive/quasar black holes.
  // The broad translucent beams establish the silhouette; pixel knots add motion.
  if (supermassive) {
    const pulse = 0.78 + 0.22 * Math.sin(now * 0.008 + id);
    const jetLength = r * (mass >= 1e9 ? 15 : 10.5);
    const jetWidth = Math.max(cell * 2.6, r * 0.72) * pulse;
    for (const sign of [-1, 1]) {
      const beam = ctx.createLinearGradient(0, sign * r * 0.65, 0, sign * jetLength);
      beam.addColorStop(0, "rgba(255,255,255,0.98)");
      beam.addColorStop(0.12, "rgba(126,235,255,0.88)");
      beam.addColorStop(0.48, "rgba(49,135,255,0.42)");
      beam.addColorStop(1, "rgba(55,105,255,0)");
      ctx.fillStyle = beam;
      ctx.beginPath();
      ctx.moveTo(-jetWidth * 0.22, sign * r * 0.65);
      ctx.lineTo(jetWidth * 0.22, sign * r * 0.65);
      ctx.lineTo(jetWidth * 0.72, sign * jetLength);
      ctx.lineTo(-jetWidth * 0.72, sign * jetLength);
      ctx.closePath(); ctx.fill();
      // Hot central spine and bright pixel knots travel outward.
      ctx.fillStyle = "rgba(205,250,255,0.95)";
      ctx.fillRect(-Math.max(1.5, cell * 0.38), sign * r * 0.8, Math.max(3, cell * 0.76), sign * (jetLength - r * 0.8));
      // Highly visible animated pixel streams travel outward along BOTH jets.
      // Use elapsed wall-clock seconds so motion continues even when simulation time is paused.
      const elapsed = now / 1000;
      for (let i = 0; i < 28; i++) {
        const phase = ((elapsed * (0.55 + (i % 5) * 0.065) + i * 0.137 + id * 0.031) % 1 + 1) % 1;
        const maxSpan = mass >= 1e9 ? 13.5 : 9.2;
        const along = r * (1.0 + phase * maxSpan);
        const sway = Math.sin(elapsed * 4.2 + i * 1.71 + id) * cell * (0.42 + phase * 1.35);
        const size = Math.max(3, cell * (1.1 + (i % 3) * 0.34) * (1 - phase * 0.24));
        const px = sway + Math.sin(elapsed * 2.8 + i * 2.1) * cell * 0.5;
        const py = sign * along;
        // Bright leading pixel.
        ctx.globalAlpha = 0.78 + 0.22 * Math.sin(elapsed * 7 + i * 1.3);
        ctx.fillStyle = i % 6 === 0 ? "#ffffff" : i % 3 === 0 ? "#d5fbff" : i % 2 === 0 ? "#8ceaff" : "#4d9dff";
        ctx.fillRect(Math.round(px / cell) * cell, Math.round(py / cell) * cell, size, size);
        // Two trailing pixels remain behind the moving knot, making direction obvious.
        for (let trail = 1; trail <= 2; trail++) {
          const trailAlong = Math.max(r * 0.95, along - sign * (size * trail * 2.6));
          const trailSize = Math.max(2, size * (0.68 - trail * 0.16));
          ctx.globalAlpha = 0.62 - trail * 0.19;
          ctx.fillStyle = trail === 1 ? "#79dfff" : "#3979e8";
          ctx.fillRect(Math.round((px - cell * 0.12 * trail) / cell) * cell, Math.round(trailAlong / cell) * cell, trailSize, trailSize);
        }
        ctx.globalAlpha = 1;
      }
    }
    // Animated square plasma pixels orbit through the inner accretion disk.
    for (let i = 0; i < 34; i++) {
      const phase = now * (0.0014 + (i % 5) * 0.00016) + id * 0.7 + i * 2.399;
      const orbit = diskR * (0.42 + (i % 11) * 0.052);
      const px = Math.cos(phase) * orbit; const py = Math.sin(phase) * orbit * (diskH / diskR);
      const sz = Math.max(2, cell * (i % 4 === 0 ? 1.05 : 0.65));
      ctx.fillStyle = i % 6 === 0 ? "#ffffff" : i % 2 === 0 ? "#aaf5ff" : "#4f9dff";
      ctx.fillRect(Math.round(px / sz) * sz, Math.round(py / sz) * sz, sz, sz);
    }

    // Lens-like blue halo around the nucleus, strongest for the most massive holes.
    const jetHalo = ctx.createRadialGradient(0, 0, r * 0.7, 0, 0, diskR * 2.2);
    jetHalo.addColorStop(0, "rgba(185,248,255,0.26)");
    jetHalo.addColorStop(0.45, "rgba(60,145,255,0.13)");
    jetHalo.addColorStop(1, "rgba(40,90,255,0)");
    ctx.fillStyle = jetHalo;
    ctx.beginPath(); ctx.ellipse(0, 0, diskR * 1.9, diskH * 2.5, 0, 0, Math.PI * 2); ctx.fill();
  }

  // Event horizon remains perfectly black with a hot pixel rim.
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.72, 0, Math.PI * 2);
  ctx.fillStyle = "#030207";
  ctx.fill();
  ctx.strokeStyle = supermassive ? "#a8f3ff" : "#ffcf48";
  ctx.lineWidth = Math.max(2, cell * 0.7);
  ctx.stroke();
  ctx.restore();
}

function drawPlanet(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, body: Body, now: number): void {
  // Render every world as its own deterministic pixel-art sprite. The grid is
  // intentionally low-resolution and nearest-neighbour-like, matching the
  // retro space aesthetic while keeping the simulation fully procedural.
  const cells = 28;
  const cell = (r * 2) / cells;
  const seed = body.id * 7919 + 41;
  const base = body.skin === "earth" ? "#277eae" : body.color;
  const secondary = body.skin === "earth" ? "#55a83f" : body.color2;

  ctx.save();
  ctx.imageSmoothingEnabled = false;
  for (let iy = 0; iy < cells; iy++) {
    for (let ix = 0; ix < cells; ix++) {
      const nx = ((ix + 0.5) / cells) * 2 - 1;
      const ny = ((iy + 0.5) / cells) * 2 - 1;
      const d2 = nx * nx + ny * ny;
      if (d2 > 1) continue;

      const nz = Math.sqrt(Math.max(0, 1 - d2));
      const light = Math.max(0, Math.min(1, (-nx * 0.48 - ny * 0.58 + nz * 0.42 + 0.35)));
      const rnd = mulberry(seed + ix * 92821 + iy * 68917)();
      let surface = base;

      if (body.skin === "bands" || body.skin === "ice") {
        const wave = Math.sin(iy * 0.88 + Math.sin(ix * 0.23 + body.id) * 1.6 + now * 0.035);
        if (wave > 0.16 || (body.skin === "ice" && wave > -0.22)) surface = secondary;
        if (rnd > 0.91) surface = mix(surface, "#ffffff", 0.55);
      } else if (body.skin === "earth") {
        // Broad continent-like patches plus blocky white cloud formations.
        const continent = Math.sin(ix * 0.34 + body.id) + Math.cos(iy * 0.29) + Math.sin((ix + iy) * 0.22);
        if (continent > 0.68) surface = secondary;
        if (continent > 1.1 && rnd > 0.35) surface = "#438d37";
        if ((rnd > 0.91 && ny < 0.55) || (Math.sin(ix * 0.55 + iy * 0.27) > 1.32 && rnd > 0.35)) surface = "#f5f1df";
        if (rnd < 0.045) surface = "#78c9df";
      } else if (body.skin === "rock" || body.skin === "dust") {
        if (rnd > 0.82) surface = mix(base, secondary, 0.72);
        else if (rnd < 0.12) surface = mix(base, "#251f2c", 0.55);
      } else {
        if (rnd > 0.88) surface = mix(base, secondary, 0.72);
        else if (rnd < 0.08) surface = mix(base, "#ffffff", 0.24);
      }

      // A crisp stepped terminator and simple pixel shading give the sphere depth.
      if (light < 0.22) surface = mix(surface, "#101625", 0.78);
      else if (light < 0.42) surface = mix(surface, "#17243a", 0.48);
      else if (light > 0.82) surface = mix(surface, "#fff5d9", 0.22);

      ctx.fillStyle = surface;
      ctx.fillRect(x - r + ix * cell, y - r + iy * cell, Math.ceil(cell + 0.15), Math.ceil(cell + 0.15));
    }
  }

  // Small square craters on rocky worlds, with a highlight/shadow pair.
  if (body.skin === "rock" || body.skin === "dust") {
    const crater = mulberry(seed + 991);
    const count = Math.min(14, Math.max(3, Math.floor(r / 3)));
    for (let i = 0; i < count; i++) {
      const cx = x + (crater() * 1.5 - 0.75) * r;
      const cy = y + (crater() * 1.5 - 0.75) * r;
      if ((cx - x) ** 2 + (cy - y) ** 2 > r * r * 0.72) continue;
      const size = Math.max(1, cell * (0.65 + crater() * 0.8));
      ctx.fillStyle = "rgba(13,18,30,0.48)";
      ctx.fillRect(cx, cy, size * 1.7, size);
      ctx.fillStyle = "rgba(255,235,195,0.3)";
      ctx.fillRect(cx, cy, size, Math.max(1, size * 0.45));
    }
  }

  // Stepped dark outline keeps the sprite readable against the starfield.
  ctx.strokeStyle = "rgba(5, 9, 20, 0.9)";
  ctx.lineWidth = Math.max(1, cell * 0.65);
  ctx.beginPath();
  ctx.arc(x, y, r - cell * 0.15, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

function drawCompact(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string): void {
  const glow = ctx.createRadialGradient(x, y, r * 0.2, x, y, r * 3.4);
  glow.addColorStop(0, hexAlpha(color, 0.7));
  glow.addColorStop(1, hexAlpha(color, 0));
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(x, y, r * 3.4, 0, Math.PI * 2);
  ctx.fill();
  const core = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, 0, x, y, r);
  core.addColorStop(0, "#ffffff");
  core.addColorStop(1, color);
  ctx.fillStyle = core;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(performance.now() * 0.0018);
  const beam = ctx.createLinearGradient(-r * 4, 0, r * 4, 0);
  beam.addColorStop(0, "rgba(160,210,255,0)");
  beam.addColorStop(0.5, "rgba(220,240,255,0.55)");
  beam.addColorStop(1, "rgba(160,210,255,0)");
  ctx.fillStyle = beam;
  ctx.fillRect(-r * 4, -Math.max(1, r * 0.12), r * 8, Math.max(2, r * 0.24));
  ctx.restore();
}

function drawWhiteDwarfPixel(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string, now: number, id: number): void {
  const glow = ctx.createRadialGradient(x, y, r * 0.25, x, y, r * 3.6);
  glow.addColorStop(0, "rgba(210,235,255,0.65)"); glow.addColorStop(0.45, hexAlpha(color, 0.24)); glow.addColorStop(1, hexAlpha(color, 0));
  ctx.fillStyle = glow; ctx.fillRect(x-r*3.6,y-r*3.6,r*7.2,r*7.2);
  const cell=Math.max(2,Math.ceil(r/5)), cells=Math.max(5,Math.ceil(r/cell)); ctx.save(); ctx.imageSmoothingEnabled=false;
  for(let gy=-cells;gy<=cells;gy++) for(let gx=-cells;gx<=cells;gx++){const d=gx*gx+gy*gy;if(d>cells*cells)continue;const f=Math.sin(now*0.004+gx*1.8+gy*2.2+id);ctx.fillStyle=d<cells*cells*0.28?"#ffffff":f>0.25?"#dff5ff":d<cells*cells*0.7?"#a8d8ff":color;ctx.fillRect(Math.round(x+gx*cell),Math.round(y+gy*cell),cell,cell);}
  for(let i=0;i<4;i++){const a=i*Math.PI/2+now*0.0007+id,rr=r*(1.35+0.12*Math.sin(now*0.003+i));ctx.fillStyle=i%2?"#a9e7ff":"#ffffff";ctx.fillRect(Math.round((x+Math.cos(a)*rr)/cell)*cell,Math.round((y+Math.sin(a)*rr)/cell)*cell,cell,cell);}ctx.restore();
}

function drawNeutronPixel(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string, now: number, id: number): void {
  const glow=ctx.createRadialGradient(x,y,r*0.2,x,y,r*4.4);glow.addColorStop(0,"rgba(235,250,255,0.85)");glow.addColorStop(0.22,hexAlpha(color,0.42));glow.addColorStop(1,hexAlpha(color,0));ctx.fillStyle=glow;ctx.fillRect(x-r*4.4,y-r*4.4,r*8.8,r*8.8);
  const cell=Math.max(2,Math.ceil(r/4));ctx.save();ctx.translate(x,y);ctx.rotate(now*0.0018+id*0.17);ctx.imageSmoothingEnabled=false;const z=Math.max(5,Math.ceil(r*1.25/cell)*cell);ctx.fillStyle="#eafaff";ctx.fillRect(-z/2,-z/2,z,z);ctx.fillStyle=color;ctx.fillRect(-z/2,-z/2,cell,cell);ctx.fillRect(z/2-cell,z/2-cell,cell,cell);const pulse=0.7+0.3*Math.sin(now*0.009+id);ctx.fillStyle=`rgba(150,220,255,${0.38*pulse})`;ctx.fillRect(-r*3.1,-cell,r*6.2,cell*2);ctx.fillStyle=`rgba(235,250,255,${0.75*pulse})`;ctx.fillRect(-r*2.6,-cell/2,r*5.2,cell);ctx.restore();
}

function drawComet(ctx: CanvasRenderingContext2D, sim: Simulation, body: Body, x: number, y: number, r: number): void {
  const speed = Math.hypot(body.vx, body.vy);
  const len = Math.min(180, 18 + speed * sim.camera.k * 1.6);
  let tx = 1;
  let ty = 0;
  if (speed > 1e-6) {
    tx = -body.vx / speed;
    ty = -body.vy / speed;
  }
  const grad = ctx.createLinearGradient(x, y, x + tx * len, y + ty * len);
  grad.addColorStop(0, "rgba(232, 240, 246, 0.7)");
  grad.addColorStop(1, "rgba(232, 240, 246, 0)");
  ctx.strokeStyle = grad;
  ctx.lineWidth = Math.max(2, r * 0.7);
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x + tx * len, y + ty * len);
  ctx.stroke();
  const core = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, 0, x, y, r);
  core.addColorStop(0, "#ffffff");
  core.addColorStop(1, "#b9c9d4");
  ctx.fillStyle = core;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}

function drawRings(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, front: boolean): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-0.5);
  ctx.scale(1, 0.38);
  ctx.beginPath();
  if (front) ctx.arc(0, 0, r * 1.85, 0, Math.PI);
  else ctx.arc(0, 0, r * 1.85, Math.PI, Math.PI * 2);
  ctx.strokeStyle = front ? "rgba(226, 210, 180, 0.85)" : "rgba(196, 176, 146, 0.45)";
  ctx.lineWidth = r * 0.28;
  ctx.stroke();
  ctx.restore();
}

function drawArrow(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number): void {
  const angle = Math.atan2(y1 - y0, x1 - x0);
  ctx.strokeStyle = "rgba(244,244,245,0.9)";
  ctx.fillStyle = "rgba(244,244,245,0.9)";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.lineTo(x1, y1);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x1 - Math.cos(angle - 0.4) * 10, y1 - Math.sin(angle - 0.4) * 10);
  ctx.lineTo(x1 - Math.cos(angle + 0.4) * 10, y1 - Math.sin(angle + 0.4) * 10);
  ctx.closePath();
  ctx.fill();
}

function drawLabel(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, selected: boolean): void {
  ctx.font = "12px Segoe UI, system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "bottom";
  ctx.lineWidth = 3;
  ctx.strokeStyle = "rgba(7,8,12,0.85)";
  ctx.strokeText(text, x, y);
  ctx.fillStyle = selected ? "#f4f4f5" : "rgba(244,244,245,0.78)";
  ctx.fillText(text, x, y);
}

function drawVisit(ctx: CanvasRenderingContext2D, width: number, height: number, entry: CatalogEntry, now: number): void {
  const rs = schwarzschildAU(entry.mass);
  const sunR = 0.00465047;
  const narrow = width < 960;
  const cx = narrow ? width * 0.5 : width * 0.4;
  const cy = narrow ? height * 0.3 : height * 0.48;
  const budget = Math.min(width, height) * (narrow ? 0.32 : 0.4);

  if (entry.regime === "stellar") {
    const span = sunR * 6;
    const px = (au: number) => (au / span) * budget;
    const starRadius = Math.max(24, px(sunR));
    drawOrbit(ctx, cx, cy, starRadius * 2.5, "rgba(244,244,245,0.08)");
    if (entry.category === "star") drawStar(ctx, cx, cy, starRadius, entry.color, now, entry.id.length * 19);
    else if (entry.category === "neutron") drawCompact(ctx, cx, cy, Math.max(12, starRadius * 0.55), entry.color);
    else drawHole(ctx, cx, cy, Math.max(12, starRadius * 0.45), now, entry.id.length * 19, entry.mass);
    const iy = cy + starRadius + Math.min(width, height) * 0.13;
    ctx.font = "12px Segoe UI, system-ui, sans-serif";
    ctx.fillStyle = "rgba(244,244,245,0.8)";
    ctx.textAlign = "center";
    ctx.fillText(entry.category === "star" ? "estrela — tamanho ilustrativo" : entry.category === "neutron" ? "estrela de nêutrons — tamanho ilustrativo" : "horizonte — fora de escala", cx, iy + 18);
    ctx.font = "11px Segoe UI, system-ui, sans-serif";
    ctx.fillStyle = "rgba(244,244,245,0.58)";
    ctx.fillText(entry.distance, cx, iy + 38);
    return;
  }

  const neptune = 30.07;
  const span = entry.regime === "galactic" ? Math.max(rs * 3.1, 1.15) : rs * 2.45;
  const px = (au: number) => (au / span) * budget * 2;
  const orbits = [
    { a: 0.387, name: "Mercúrio" },
    { a: 0.723, name: "Vênus" },
    { a: 1, name: "Terra" },
    { a: 1.524, name: "Marte" },
    { a: 5.203, name: "Júpiter" },
    { a: 9.537, name: "Saturno" },
    { a: 19.19, name: "Urano" },
    { a: neptune, name: "Netuno" },
  ];
  for (const orbit of orbits) {
    const rad = px(orbit.a);
    if (rad < 5 || rad > Math.min(width, height) * 0.48) continue;
    drawOrbit(ctx, cx, cy, rad, "rgba(244,244,245,0.2)");
    if (rad > 18) {
      ctx.font = "11px Segoe UI, system-ui, sans-serif";
      ctx.fillStyle = "rgba(244,244,245,0.55)";
      ctx.textAlign = "left";
      ctx.fillText(orbit.name, cx + rad + 4, cy);
    }
  }
  const sunPx = px(sunR);
  if (sunPx >= 2 && sunPx < budget) drawSunDisc(ctx, cx, cy, sunPx);
  else if (entry.regime === "ultra") {
    ctx.beginPath();
    ctx.arc(cx, cy, 2, 0, Math.PI * 2);
    ctx.fillStyle = "#f4f4f5";
    ctx.fill();
  }
  drawHole(ctx, cx, cy, Math.max(10, px(rs)), now, 7, entry.mass);
  ctx.font = "12px Segoe UI, system-ui, sans-serif";
  ctx.fillStyle = "rgba(244,244,245,0.72)";
  ctx.textAlign = "center";
  ctx.fillText("Escala real, em unidades astronômicas", cx, Math.min(height - 24, cy + px(rs) + 36));
}

function drawOrbit(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string): void {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  ctx.stroke();
}

function drawSunDisc(ctx: CanvasRenderingContext2D, x: number, y: number, r: number): void {
  const g = ctx.createRadialGradient(x, y, r * 0.1, x, y, r);
  g.addColorStop(0, "#fff6e8");
  g.addColorStop(0.6, "#f0c48a");
  g.addColorStop(1, "#a86432");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}

function hexAlpha(hex: string, alpha: number): string {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = Number.parseInt(full, 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function mix(a: string, b: string, t: number): string {
  const pa = rgb(a);
  const pb = rgb(b);
  const r = Math.round(pa[0] + (pb[0] - pa[0]) * t);
  const g = Math.round(pa[1] + (pb[1] - pa[1]) * t);
  const bl = Math.round(pa[2] + (pb[2] - pa[2]) * t);
  return `rgb(${r}, ${g}, ${bl})`;
}

function rgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = Number.parseInt(full, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function mulberry(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
