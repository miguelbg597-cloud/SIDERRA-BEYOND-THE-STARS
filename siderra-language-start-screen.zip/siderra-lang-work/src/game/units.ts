/** 1 unit = 1 AU. G chosen so a 1 M☉ body has a 1-year circular orbit at 1 AU. */
export const YEAR = 365.256363;
export const G = (4 * Math.PI * Math.PI) / (YEAR * YEAR);
export const SOFT = 0.02;
export const SOFT2 = SOFT * SOFT;
export const AU_KM = 149_597_870.7;
export const RS_KM_PER_MSUN = 2.95325;

export function schwarzschildAU(massSolar: number): number {
  return (massSolar * RS_KM_PER_MSUN) / AU_KM;
}

/** Compress only above 1 M☉ so planets stay honest and ultramassive holes stay watchable. */
export function playableMass(massSolar: number): number {
  if (!(massSolar > 0)) return 1e-12;
  if (massSolar <= 1) return massSolar;
  return Math.pow(massSolar, 0.35);
}

export function circularSpeed(mass: number, radius: number): number {
  if (radius <= 0 || mass <= 0) return 0;
  return Math.sqrt((G * mass) / radius);
}

export function formatMass(massSolar: number): string {
  if (!Number.isFinite(massSolar)) return "—";
  const abs = Math.abs(massSolar);
  if (abs >= 1e9) {
    const v = abs / 1e9;
    return `${trim(v)} bilhões de M☉`;
  }
  if (abs >= 1e6) return `${trim(abs / 1e6)} milhões de M☉`;
  if (abs >= 1e3) return `${trim(abs / 1e3)} mil M☉`;
  if (abs >= 0.01) return `${trim(abs)} M☉`;
  const earth = abs / 3.003e-6;
  if (earth >= 0.01) return `${trim(earth)} M⊕`;
  return `${abs.toExponential(1)} M☉`;
}

export function formatAU(au: number): string {
  const abs = Math.abs(au);
  if (abs >= 100) return `${abs.toFixed(0)} UA`;
  if (abs >= 10) return `${abs.toFixed(1)} UA`;
  if (abs >= 0.01) return `${abs.toFixed(2)} UA`;
  return `${abs.toExponential(1)} UA`;
}

export function formatDays(days: number): string {
  const years = days / YEAR;
  const abs = Math.abs(years);
  if (abs < 1 / YEAR) return `${days.toFixed(2)} dias`;
  if (abs < 0.08) return `${days.toFixed(1)} dias`;
  if (abs < 100) return `${trim(years)} anos`;
  if (abs < 1e6) return `${Math.round(years).toLocaleString("pt-BR")} anos`;
  return `${years.toExponential(2)} anos`;
}

export function formatRate(daysPerSecond: number): string {
  if (daysPerSecond < 0.01) return `${daysPerSecond.toExponential(1)} dias/s`;
  if (daysPerSecond < 10) return `${trim(daysPerSecond)} dias/s`;
  if (daysPerSecond < 1000) return `${Math.round(daysPerSecond)} dias/s`;
  return `${trim(daysPerSecond / 1000)} mil dias/s`;
}

function trim(n: number): string {
  const digits = n >= 100 ? 0 : n >= 10 ? 1 : 2;
  return n
    .toFixed(digits)
    .replace(/\.0+$/, "")
    .replace(/(\.\d)0$/, "$1")
    .replace(".", ",");
}
