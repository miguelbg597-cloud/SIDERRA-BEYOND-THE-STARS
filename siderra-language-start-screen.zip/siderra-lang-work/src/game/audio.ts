import type { Sfx } from "@/game/sim";

export class Score {
  private ctx: AudioContext | null = null;
  enabled = true;

  unlock(): void {
    if (!this.enabled) return;
    const ctx = this.ensure();
    if (ctx.state === "suspended") void ctx.resume();
  }

  play(sfx: Sfx): void {
    if (!sfx || !this.enabled) return;
    const ctx = this.ensure();
    if (ctx.state !== "running") return;
    if (sfx === "hit") this.thud(ctx, 140, 0.18, 0.05);
    else if (sfx === "swallow") this.thud(ctx, 70, 0.45, 0.06);
    else this.boom(ctx);
  }

  private ensure(): AudioContext {
    if (!this.ctx) this.ctx = new AudioContext();
    return this.ctx;
  }

  private thud(ctx: AudioContext, freq: number, dur: number, gain: number): void {
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const amp = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(freq, t);
    osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq * 0.4), t + dur);
    amp.gain.setValueAtTime(gain, t);
    amp.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(amp);
    amp.connect(ctx.destination);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  private boom(ctx: AudioContext): void {
    this.thud(ctx, 90, 0.6, 0.07);
    const t = ctx.currentTime;
    const buffer = ctx.createBuffer(1, ctx.sampleRate * 0.4, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 800;
    const amp = ctx.createGain();
    amp.gain.setValueAtTime(0.04, t);
    amp.gain.exponentialRampToValueAtTime(0.0001, t + 0.4);
    noise.connect(filter);
    filter.connect(amp);
    amp.connect(ctx.destination);
    noise.start(t);
    noise.stop(t + 0.42);
  }
}

/** Gentle synthesized ambient soundtrack for the Siderra space sandbox. */
export class AmbientMusic {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private drones: OscillatorNode[] = [];
  private timer: number | null = null;
  private noteIndex = 0;
  private readonly notes = [220, 261.63, 329.63, 293.66, 196, 246.94, 293.66, 392];

  async start(): Promise<void> {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.0001;
      this.master.connect(this.ctx.destination);
      // Soft, warm pad; no vocals or percussion.
      for (const [frequency, volume] of [[110, 0.035], [164.81, 0.018], [220, 0.012]] as const) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = frequency;
        gain.gain.value = volume;
        osc.connect(gain);
        gain.connect(this.master);
        osc.start();
        this.drones.push(osc);
      }
    }
    await this.ctx.resume();
    const now = this.ctx.currentTime;
    this.master!.gain.cancelScheduledValues(now);
    this.master!.gain.setTargetAtTime(0.55, now, 1.2);
    if (this.timer === null) {
      this.playNote();
      this.timer = window.setInterval(() => this.playNote(), 1850);
    }
  }

  stop(): void {
    if (this.timer !== null) window.clearInterval(this.timer);
    this.timer = null;
    if (this.ctx && this.master) {
      const now = this.ctx.currentTime;
      this.master.gain.cancelScheduledValues(now);
      this.master.gain.setTargetAtTime(0.0001, now, 0.35);
    }
  }

  private playNote(): void {
    if (!this.ctx || !this.master || this.ctx.state !== "running") return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const freq = this.notes[this.noteIndex % this.notes.length];
    this.noteIndex += 1;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    osc.type = "sine";
    osc.frequency.value = freq;
    filter.type = "lowpass";
    filter.frequency.value = 900;
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(0.055, t + 0.18);
    gain.gain.setTargetAtTime(0.0001, t + 0.45, 1.0);
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.master);
    osc.start(t);
    osc.stop(t + 3.5);
  }
}
