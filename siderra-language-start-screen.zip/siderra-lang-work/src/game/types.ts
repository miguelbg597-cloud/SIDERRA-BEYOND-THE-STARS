export type Kind =
  | "star"
  | "planet"
  | "gas"
  | "comet"
  | "asteroid"
  | "white-dwarf"
  | "neutron"
  | "black-hole";

export type Skin = "star" | "earth" | "rock" | "bands" | "ice" | "dust" | "comet" | "hole" | "compact";

export type Body = {
  id: number;
  name: string;
  kind: Kind;
  skin: Skin;
  x: number;
  y: number;
  vx: number;
  vy: number;
  /** Catalog / true mass in solar masses. */
  mass: number;
  /** Mass actually used by gravity. */
  gravMass: number;
  radius: number;
  pinned: boolean;
  color: string;
  color2: string;
  rings: boolean;
  anchor: boolean;
  catalogId?: string;
  note?: string;
  /** Original orbital radius around the anchor, for the guide ring. */
  orbitA?: number;
  /** Parent planet for stable hierarchical moon orbits in presets. */
  satelliteParentId?: number;
  satelliteOrbitA?: number;
  satellitePhase?: number;
  satelliteAngularSpeed?: number;
  alive: boolean;
  trail: Array<{ x: number; y: number }>;
};

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
};

export type Shock = {
  x: number;
  y: number;
  age: number;
  dur: number;
  radius: number;
};

export type MassMode = "play" | "real";

export type PresetName = "solar" | "binary" | "fall" | "cluster" | "empty" | "fictional";

export type SpawnTool =
  | "move"
  | "meteor"
  | "erase"
  | "explode"
  | "star"
  | "planet"
  | "gas"
  | "comet"
  | "asteroid"
  | "white-dwarf"
  | "neutron"
  | "black-hole";

export const KIND_LABEL: Record<Kind, string> = {
  star: "Estrela",
  planet: "Planeta rochoso",
  gas: "Gigante gasoso",
  comet: "Cometa",
  asteroid: "Asteroide",
  "white-dwarf": "Anã branca",
  neutron: "Estrela de nêutrons",
  "black-hole": "Buraco negro",
};
