import { catalogById, type CatalogEntry } from "@/game/catalog";
import type { Body, Kind, MassMode, Particle, PresetName, Shock, Skin } from "@/game/types";
import { circularSpeed, G, playableMass, schwarzschildAU, SOFT2, YEAR } from "@/game/units";

const MAX_BODIES = 72;
const MAX_PARTICLES = 1200;

export type Sfx = "hit" | "swallow" | "boom" | null;

type MakeOpts = {
  name: string;
  kind: Kind;
  skin: Skin;
  mass: number;
  radius: number;
  x: number;
  y: number;
  vx?: number;
  vy?: number;
  color: string;
  color2?: string;
  rings?: boolean;
  anchor?: boolean;
  pinned?: boolean;
  catalogId?: string;
  note?: string;
  orbitA?: number;
  satelliteParentId?: number;
  satelliteOrbitA?: number;
  satellitePhase?: number;
  satelliteAngularSpeed?: number;
};

export class Simulation {
  bodies: Body[] = [];
  particles: Particle[] = [];
  shocks: Shock[] = [];
  supernovaFlash: { x: number; y: number; age: number; dur: number } | null = null;
  time = 0;
  timescale = 90;
  paused = false;
  collisions = true;
  gravity = true;
  trails = true;
  guides = true;
  nebulae = true;
  massMode: MassMode = "play";
  camera = { x: 1.4, y: 0, k: 140 };
  selectedId: number | null = null;
  dragId: number | null = null;
  shake = 0;
  notice = "Arraste um planeta para fora da órbita, ou solte um meteoro.";
  sfx: Sfx = null;
  private nextId = 1;
  private ax = new Float64Array(16);
  private ay = new Float64Array(16);

  constructor() {
    this.load("solar");
  }

  massOf(trueMass: number): number {
    return this.massMode === "real" ? Math.max(trueMass, 1e-14) : playableMass(trueMass);
  }

  load(preset: PresetName): void {
    this.bodies = [];
    this.particles = [];
    this.shocks = [];
    this.supernovaFlash = null;
    this.time = 0;
    this.selectedId = null;
    this.dragId = null;
    this.nextId = 1;
    this.shake = 0;
    this.paused = false;
    if (preset === "solar") {
      this.guides = true;
      this.buildSolar();
    } else if (preset === "binary") this.buildBinary();
    else if (preset === "fall") this.buildFall();
    else if (preset === "cluster") this.buildCluster();
    else if (preset === "fictional") this.buildFictional();
    else {
      this.guides = false;
      this.notice = "Vazio. Escolha um corpo e arraste para lançar.";
    }
    if (preset === "fall") {
      this.timescale = 6;
      this.notice = "Tudo largado, sem velocidade orbital. O Sol puxa.";
    } else if (preset !== "empty") {
      this.timescale = 90;
    }
  }

  private buildFictional(): void {
    // Fictional Siderra system: Gargantua at the center, with planets and moons.
    const gargantua = this.make({
      name: "Gargântua",
      kind: "black-hole",
      skin: "hole",
      mass: 100_000_000_000,
      radius: 0.62,
      x: 0,
      y: 0,
      color: "#171522",
      color2: "#e9a65a",
      anchor: true,
    });
    const rows: Array<[string, number, number, number, string, string, number, Kind, Skin, boolean?]> = [
      ["Ícaro", 1.2e-6, 2.4, 0.12, "#c8bbae", "#8d8275", 0.4, "planet", "rock"],
      ["Véspera", 3.1e-6, 3.8, 0.15, "#e4c48a", "#b08a55", 1.3, "planet", "rock"],
      ["Nácar", 3.003e-6, 5.6, 0.16, "#3d7ec2", "#2c6b45", 2.2, "planet", "earth"],
      ["Brasa", 4.2e-7, 7.4, 0.11, "#c4653c", "#7d3a28", 2.9, "planet", "rock"],
      ["Olimpo", 9.545e-4, 10.0, 0.34, "#e0c49a", "#a07c4e", 0.5, "gas", "bands"],
      ["Anel", 2.857e-4, 13.5, 0.29, "#ead7ae", "#c2a36b", 1.8, "gas", "bands", true],
      ["Safira", 4.366e-5, 17.0, 0.18, "#c5e6e4", "#7eb8c0", 2.5, "gas", "ice"],
      ["Abismo", 5.151e-5, 21.0, 0.18, "#3e62c8", "#24367a", 3.4, "gas", "bands"],
    ];
    const planets: Body[] = [];
    for (const row of rows) {
      const [name, mass, a, radius, color, color2, angle, kind, skin, rings] = row;
      planets.push(this.orbit(gargantua, { name, mass, a, radius, color, color2, angle, kind, skin, rings: Boolean(rings) }));
    }
    const moonSpecs: Array<[number, string, number, number, string, string, Skin]> = [
      [2, "Luma", 0.34, 0.035, "#d8dce4", "#8e98a8", "rock"],
      [2, "Tétis", 0.52, 0.026, "#aeb8c6", "#727d8e", "ice"],
      [4, "Vulcano", 0.55, 0.045, "#d89b72", "#8c5544", "rock"],
      [4, "Névoa", 0.82, 0.038, "#b9dce2", "#6b9ca9", "ice"],
      [5, "Cíntia", 0.48, 0.04, "#d8d1bd", "#8d887d", "rock"],
      [5, "Orbe", 0.72, 0.032, "#c8d4e5", "#7b8da8", "ice"],
      [6, "Titânia", 0.58, 0.042, "#d4bfa0", "#92795f", "rock"],
      [7, "Gelo", 0.5, 0.035, "#d9edf0", "#8bbac4", "ice"],
    ];
    for (const [planetIndex, name, a, radius, color, color2, skin] of moonSpecs) {
      const planet = planets[planetIndex]!;
      const angle = planetIndex * 1.17 + a * 2.1;
      const v = circularSpeed(planet.gravMass, a);
      this.make({ name, kind: "planet", skin, mass: 1e-8, radius, x: planet.x + Math.cos(angle) * a, y: planet.y + Math.sin(angle) * a,
        vx: planet.vx - Math.sin(angle) * v, vy: planet.vy + Math.cos(angle) * v, color, color2,
        satelliteParentId: planet.id, satelliteOrbitA: a, satellitePhase: angle,
        satelliteAngularSpeed: Math.sqrt((G * planet.gravMass) / (a * a * a)) });
    }
    this.notice = "Sistema fictício de Siderra: Gargântua no centro, oito planetas e luas em órbita.";
  }

  private buildFall(): void {
    this.buildSolar();
    for (const body of this.bodies) {
      if (!body.anchor) {
        body.vx = 0;
        body.vy = 0;
        body.orbitA = undefined;
      }
    }
    this.guides = false;
  }

  private buildBinary(): void {
    const sep = 2.4;
    const mass = 1.15;
    const speed = Math.sqrt((G * mass) / (2 * sep));
    this.make({
      name: "Álfa",
      kind: "star",
      skin: "star",
      mass,
      radius: 0.32,
      x: -sep / 2,
      y: 0,
      vx: 0,
      vy: speed,
      color: "#ffd0a4",
      color2: "#ff8a4a",
    });
    this.make({
      name: "Beta",
      kind: "star",
      skin: "star",
      mass,
      radius: 0.28,
      x: sep / 2,
      y: 0,
      vx: 0,
      vy: -speed,
      color: "#d5e4ff",
      color2: "#8eb4ff",
    });
    this.orbit(this.bodies[0]!, {
      name: "Cinza",
      mass: 2e-6,
      a: 4.2,
      radius: 0.1,
      color: "#b7b1a8",
      color2: "#6e6a64",
      angle: 0.6,
      kind: "planet",
      skin: "rock",
    });
    this.notice = "Duas estrelas em torno do centro comum. Empurre uma.";
    this.guides = false;
  }

  private buildCluster(): void {
    const sun = this.make({
      name: "Núcleo",
      kind: "star",
      skin: "star",
      mass: 2.4,
      radius: 0.36,
      x: 0,
      y: 0,
      color: "#ffd2a8",
      color2: "#ff7a3c",
      anchor: true,
    });
    for (let i = 0; i < 14; i++) {
      const a = 1.1 + Math.random() * 6.5;
      const angle = Math.random() * Math.PI * 2;
      const rocky = Math.random() > 0.35;
      const jitter = 0.45 + Math.random() * 0.9;
      const v = circularSpeed(sun.gravMass, a) * jitter;
      const tangent = angle + Math.PI / 2;
      this.make({
        name: rocky ? `Rocha ${i + 1}` : `Gás ${i + 1}`,
        kind: rocky ? "asteroid" : "gas",
        skin: rocky ? "dust" : "bands",
        mass: rocky ? 2e-8 * (1 + Math.random() * 20) : 1e-4 * (1 + Math.random() * 8),
        radius: rocky ? 0.05 + Math.random() * 0.05 : 0.12 + Math.random() * 0.12,
        x: Math.cos(angle) * a,
        y: Math.sin(angle) * a,
        vx: Math.cos(tangent) * v,
        vy: Math.sin(tangent) * v,
        color: rocky ? "#9a9086" : "#d7b48a",
        color2: rocky ? "#5c564e" : "#8d6844",
      });
    }
    this.notice = "Aglomerado instável. Alguma coisa vai cair.";
    this.guides = false;
  }

  private buildSolar(): void {
    const sun = this.make({ name: "Sol", kind: "star", skin: "star", mass: 1, radius: 0.34, x: 0, y: 0, color: "#ffd36b", color2: "#ff8b36", anchor: true, note: "O Sol, estrela do nosso Sistema Solar." });
    const rows: Array<[string, number, number, number, string, string, number, Kind, Skin, boolean?]> = [
      ["Mercúrio", 1.66e-7, 0.85, 0.065, "#b7ada2", "#756b63", 0.4, "planet", "rock"],
      ["Vênus", 2.45e-6, 1.25, 0.095, "#e7c28a", "#a87948", 1.3, "planet", "rock"],
      ["Terra", 3.003e-6, 1.75, 0.10, "#3d7ec2", "#2c6b45", 2.2, "planet", "earth"],
      ["Marte", 3.23e-7, 2.35, 0.08, "#c4653c", "#7d3a28", 2.9, "planet", "rock"],
      ["Júpiter", 9.545e-4, 3.8, 0.25, "#e0c49a", "#a07c4e", 0.5, "gas", "bands"],
      ["Saturno", 2.857e-4, 5.2, 0.22, "#ead7ae", "#c2a36b", 1.8, "gas", "bands", true],
      ["Urano", 4.366e-5, 6.6, 0.16, "#c5e6e4", "#7eb8c0", 2.5, "gas", "ice"],
      ["Netuno", 5.151e-5, 7.8, 0.16, "#3e62c8", "#24367a", 3.4, "gas", "bands"],
    ];
    const planets: Body[] = [];
    for (const [name, mass, a, radius, color, color2, angle, kind, skin, rings] of rows) {
      planets.push(this.orbit(sun, { name, mass, a, radius, color, color2, angle, kind, skin, rings: Boolean(rings) }));
    }
    const moonSpecs: Array<[number, string, number, number, string, string, Skin]> = [
      [2, "Lua", 0.22, 0.035, "#d8dce4", "#8e98a8", "rock"],
      [3, "Fobos", 0.16, 0.025, "#aeb8c6", "#727d8e", "rock"],
      [3, "Deimos", 0.25, 0.018, "#aeb8c6", "#727d8e", "rock"],
      [4, "Io", 0.36, 0.035, "#d89b72", "#8c5544", "rock"],
      [4, "Europa", 0.48, 0.032, "#b9dce2", "#6b9ca9", "ice"],
      [5, "Titã", 0.42, 0.04, "#d4bfa0", "#92795f", "rock"],
    ];
    for (const [planetIndex, name, a, radius, color, color2, skin] of moonSpecs) {
      const planet = planets[planetIndex]!;
      const angle = planetIndex * 1.17 + a * 2.1;
      const v = circularSpeed(planet.gravMass, a);
      this.make({ name, kind: "planet", skin, mass: 1e-8, radius, x: planet.x + Math.cos(angle) * a, y: planet.y + Math.sin(angle) * a,
        vx: planet.vx - Math.sin(angle) * v, vy: planet.vy + Math.cos(angle) * v, color, color2,
        satelliteParentId: planet.id, satelliteOrbitA: a, satellitePhase: angle,
        satelliteAngularSpeed: Math.sqrt((G * planet.gravMass) / (a * a * a)) });
    }
    this.notice = "Sistema Solar: Sol, oito planetas e luas naturais.";
    this.guides = true;
  }

  triggerCosmicEvent(): void {
    const target = this.body(this.selectedId) ?? this.bodies.find((body) => body.kind === "star") ?? this.bodies[0];
    if (!target) {
      this.notice = "Crie um astro antes de iniciar um evento cósmico.";
      return;
    }
    this.explode(target.id);
    this.notice = `Evento cósmico observado perto de ${target.name}.`;
  }

  meteorShower(): void {
    if (this.bodies.length >= MAX_BODIES - 5) {
      this.notice = "Não há espaço para uma chuva de meteoros. Apague alguns corpos primeiro.";
      return;
    }
    const center = this.body(this.selectedId) ?? this.anchor() ?? this.bodies[0];
    if (!center) {
      this.notice = "Crie um astro antes de iniciar uma chuva de meteoros.";
      return;
    }
    for (let i = 0; i < 5; i++) {
      const angle = (Math.PI * 2 * i) / 5 + Math.random() * 0.35;
      const distance = 2.2 + Math.random() * 2.8;
      this.make({
        name: `Meteoro ${i + 1}`,
        kind: "asteroid",
        skin: "rock",
        mass: 2e-10,
        radius: 0.035 + Math.random() * 0.025,
        x: center.x + Math.cos(angle) * distance,
        y: center.y + Math.sin(angle) * distance,
        vx: -Math.cos(angle) * (0.06 + Math.random() * 0.04),
        vy: -Math.sin(angle) * (0.06 + Math.random() * 0.04),
        color: "#d7c2a0",
        color2: "#8d7966",
        note: "Meteoro criado por um evento aleatório do jogo.",
      });
    }
    this.notice = "Chuva de meteoros iniciada: cinco corpos entraram na cena.";
  }

  evolveSelectedStar(): void {
    const body = this.body(this.selectedId);
    if (!body || !["star", "white-dwarf", "neutron", "black-hole"].includes(body.kind)) {
      this.notice = "Selecione uma estrela ou remanescente estelar para avançar a evolução ilustrativa.";
      return;
    }
    if (body.kind === "star") {
      body.kind = "white-dwarf"; body.skin = "compact"; body.color = "#d9edff"; body.color2 = "#ffffff";
      body.radius = Math.max(0.07, body.radius * 0.55); body.mass = Math.max(body.mass * 0.62, 1e-8);
      body.note = "Etapa ilustrativa: anã branca. A evolução real depende da massa inicial da estrela.";
    } else if (body.kind === "white-dwarf") {
      body.kind = "neutron"; body.skin = "compact"; body.color = "#80d9ff"; body.color2 = "#f2fbff";
      body.radius = Math.max(0.045, body.radius * 0.42); body.mass = Math.max(body.mass * 1.4, 1e-7);
      body.note = "Etapa ilustrativa: estrela de nêutrons. Esta sequência é simplificada para fins de exploração.";
    } else if (body.kind === "neutron") {
      body.kind = "black-hole"; body.skin = "hole"; body.color = "#a98cff"; body.color2 = "#f4c9ff";
      body.radius = Math.max(0.09, body.radius * 1.7); body.mass = Math.max(body.mass * 2.5, 1e-5);
      body.note = "Etapa ilustrativa: buraco negro. Nem toda estrela passa por esta sequência na natureza.";
    } else {
      body.kind = "star"; body.skin = "star"; body.color = "#ffcb76"; body.color2 = "#fff3c4";
      body.radius = Math.max(0.16, body.radius * 1.8); body.mass = Math.max(body.mass * 0.7, 1e-6);
      body.note = "Ciclo reiniciado para experimentação; não representa reversão física real.";
    }
    body.gravMass = this.massOf(body.mass);
    this.notice = `${body.name}: etapa estelar alterada (modo educativo simplificado).`;
  }

  private addComet(sun: Body): void {
    const rp = 1.25;
    const a = 14;
    const v = Math.sqrt(G * sun.gravMass * (2 / rp - 1 / a));
    this.make({
      name: "Cometa",
      kind: "comet",
      skin: "comet",
      mass: 1e-10,
      radius: 0.05,
      x: rp,
      y: 0,
      vx: 0,
      vy: v,
      color: "#e7eef2",
      color2: "#9fb4c2",
      note: "Órbita alongada de atelier, não os elementos reais de Halley.",
    });
  }

  private orbit(
    primary: Body,
    spec: {
      name: string;
      mass: number;
      a: number;
      radius: number;
      color: string;
      color2: string;
      angle: number;
      kind: Kind;
      skin: Skin;
      rings?: boolean;
    },
  ): Body {
    const v = circularSpeed(primary.gravMass, spec.a);
    return this.make({
      name: spec.name,
      kind: spec.kind,
      skin: spec.skin,
      mass: spec.mass,
      radius: spec.radius,
      x: primary.x + Math.cos(spec.angle) * spec.a,
      y: primary.y + Math.sin(spec.angle) * spec.a,
      vx: primary.vx - Math.sin(spec.angle) * v,
      vy: primary.vy + Math.cos(spec.angle) * v,
      color: spec.color,
      color2: spec.color2,
      rings: spec.rings,
      orbitA: spec.a,
    });
  }

  make(opts: MakeOpts): Body {
    const body: Body = {
      id: this.nextId++,
      name: opts.name,
      kind: opts.kind,
      skin: opts.skin,
      x: opts.x,
      y: opts.y,
      vx: opts.vx ?? 0,
      vy: opts.vy ?? 0,
      mass: opts.mass,
      gravMass: this.massOf(opts.mass),
      radius: opts.radius,
      pinned: Boolean(opts.pinned),
      color: opts.color,
      color2: opts.color2 ?? opts.color,
      rings: Boolean(opts.rings),
      anchor: Boolean(opts.anchor),
      catalogId: opts.catalogId,
      note: opts.note,
      orbitA: opts.orbitA,
      satelliteParentId: opts.satelliteParentId,
      satelliteOrbitA: opts.satelliteOrbitA,
      satellitePhase: opts.satellitePhase,
      satelliteAngularSpeed: opts.satelliteAngularSpeed,
      alive: true,
      trail: [],
    };
    this.bodies.push(body);
    return body;
  }

  setMassMode(mode: MassMode): void {
    this.massMode = mode;
    for (const body of this.bodies) body.gravMass = this.massOf(body.mass);
    if (mode === "real") {
      const heavy = this.heaviest();
      if (heavy && heavy.mass > 500) {
        const r = 2.15;
        const tff = (Math.PI / 2) * Math.sqrt((r * r * r) / (8 * G * heavy.gravMass + 1e-18));
        this.timescale = clamp(tff / 7, 1e-8, 30);
        this.notice = "Massa real ligada. O tempo foi desacelerado para o colapso dar para acompanhar.";
      } else {
        this.notice = "Massa real: a gravidade usa a massa de catálogo, sem compressão.";
      }
    } else {
      this.timescale = Math.max(this.timescale, 20);
      this.notice = "Gravidade observável: acima de 1 M☉ a massa entra comprimida, para a cena durar segundos e não um frame.";
    }
  }

  setTrueMass(id: number, mass: number): void {
    const body = this.body(id);
    if (!body) return;
    body.mass = clamp(mass, 1e-12, 2e11);
    body.gravMass = this.massOf(body.mass);
  }

  frame(dtReal: number): number {
    const dt = Math.min(Math.max(dtReal, 0), 0.05);
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 22);
    let advanced = 0;
    if (!this.paused && this.timescale > 0) {
      let days = this.timescale * dt;
      const step = this.stepSize();
      let guard = 0;
      while (days > 1e-12 && guard < 56) {
        const h = Math.min(step, days);
        this.integrate(h);
        this.collide();
        days -= h;
        advanced += h;
        guard++;
      }
    }
    this.updateFx(advanced, dt);
    return advanced;
  }

  private stepSize(): number {
    const bodies = this.bodies;
    const n = bodies.length;
    if (n < 2) return 0.25;
    let minT = Infinity;
    if (n <= 28) {
      for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) minT = Math.min(minT, this.pairPeriod(bodies[i]!, bodies[j]!));
      }
    } else {
      let heavy = bodies[0]!;
      for (const body of bodies) if (body.gravMass > heavy.gravMass) heavy = body;
      for (const body of bodies) if (body !== heavy) minT = Math.min(minT, this.pairPeriod(body, heavy));
    }
    if (!Number.isFinite(minT)) return 0.25;
    return clamp(minT / 48, 1e-8, 0.4);
  }

  private pairPeriod(a: Body, b: Body): number {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const r = Math.sqrt(dx * dx + dy * dy) + 0.01;
    const mu = G * (a.gravMass + b.gravMass) + 1e-18;
    return 2 * Math.PI * Math.sqrt((r * r * r) / mu);
  }

  private integrate(h: number): void {
    const n = this.bodies.length;
    if (this.ax.length < n) {
      this.ax = new Float64Array(n);
      this.ay = new Float64Array(n);
    }
    const ax = this.ax;
    const ay = this.ay;
    if (this.gravity) this.accelerations(ax, ay, n);
    else {
      ax.fill(0, 0, n);
      ay.fill(0, 0, n);
    }
    for (let i = 0; i < n; i++) {
      const body = this.bodies[i]!;
      if (body.pinned || body.id === this.dragId) continue;
      body.vx += ax[i]! * h * 0.5;
      body.vy += ay[i]! * h * 0.5;
      body.x += body.vx * h;
      body.y += body.vy * h;
    }
    if (this.gravity) this.accelerations(ax, ay, n);
    for (let i = 0; i < n; i++) {
      const body = this.bodies[i]!;
      if (body.pinned || body.id === this.dragId) continue;
      body.vx += ax[i]! * h * 0.5;
      body.vy += ay[i]! * h * 0.5;
    }
    // Keep preset moons in a hierarchical orbit around their assigned planet.
    // The global N-body approximation can otherwise transfer a moon to a nearby planet
    // because the scene's visual distances are compressed compared with real Hill spheres.
    for (const moon of this.bodies) {
      if (moon.satelliteParentId === undefined || moon.satelliteOrbitA === undefined || moon.satellitePhase === undefined) continue;
      const parent = this.body(moon.satelliteParentId);
      if (!parent || !parent.alive || moon.id === this.dragId) continue;
      const omega = moon.satelliteAngularSpeed ?? 0;
      moon.satellitePhase += omega * h;
      const a = moon.satelliteOrbitA;
      const phase = moon.satellitePhase;
      moon.x = parent.x + Math.cos(phase) * a;
      moon.y = parent.y + Math.sin(phase) * a;
      moon.vx = parent.vx - Math.sin(phase) * a * omega;
      moon.vy = parent.vy + Math.cos(phase) * a * omega;
    }
    this.time += h;
  }

  private accelerations(ax: Float64Array, ay: Float64Array, n: number): void {
    ax.fill(0, 0, n);
    ay.fill(0, 0, n);
    const bodies = this.bodies;
    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        const a = bodies[i]!;
        const b = bodies[j]!;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const r2 = dx * dx + dy * dy + SOFT2;
        const inv = 1 / (r2 * Math.sqrt(r2));
        const s = G * inv;
        const ai = s * b.gravMass;
        const aj = s * a.gravMass;
        ax[i] = (ax[i] ?? 0) + dx * ai;
        ay[i] = (ay[i] ?? 0) + dy * ai;
        ax[j] = (ax[j] ?? 0) - dx * aj;
        ay[j] = (ay[j] ?? 0) - dy * aj;
      }
    }
  }

  private collide(): void {
    if (!this.collisions) return;
    let guard = 0;
    let again = true;
    while (again && guard++ < 24) {
      again = false;
      const list = this.bodies;
      for (let i = 0; i < list.length && !again; i++) {
        for (let j = i + 1; j < list.length; j++) {
          const a = list[i]!;
          const b = list[j]!;
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const reach = a.radius + b.radius;
          if (dx * dx + dy * dy <= reach * reach) {
            this.resolve(a, b);
            this.bodies = this.bodies.filter((body) => body.alive);
            again = true;
            break;
          }
        }
      }
    }
  }

  private resolve(a: Body, b: Body): void {
    const score = (body: Body) => (body.kind === "black-hole" ? 1e15 : 0) + body.gravMass + body.mass * 1e-6;
    const keep = score(b) > score(a) ? b : a;
    const drop = keep === a ? b : a;
    const dx = drop.x - keep.x;
    const dy = drop.y - keep.y;
    const dist = Math.hypot(dx, dy) || 1e-6;
    const nx = dx / dist;
    const ny = dy / dist;
    const rvx = drop.vx - keep.vx;
    const rvy = drop.vy - keep.vy;
    const rel = Math.hypot(rvx, rvy);
    const hole = keep.kind === "black-hole" || drop.kind === "black-hole";
    const bothStars = a.kind === "star" && b.kind === "star";
    const absorb = drop.gravMass < keep.gravMass * 0.08 && keep.gravMass > drop.gravMass * 8;
    const gentle = rel < 0.01;

    if (hole || bothStars || absorb || gentle) {
      this.merge(keep, drop, bothStars);
      return;
    }

    const relN = rvx * nx + rvy * ny;
    const e = 0.32;
    const m1 = Math.max(keep.gravMass, 1e-12);
    const m2 = Math.max(drop.gravMass, 1e-12);
    if (relN < 0) {
      const impulse = (-(1 + e) * relN) / (1 / m1 + 1 / m2);
      if (!keep.pinned) {
        keep.vx -= (impulse * nx) / m1;
        keep.vy -= (impulse * ny) / m1;
      }
      if (!drop.pinned) {
        drop.vx += (impulse * nx) / m2;
        drop.vy += (impulse * ny) / m2;
      }
    }
    const pen = keep.radius + drop.radius - dist + 0.002;
    const inv = (keep.pinned ? 0 : 1) + (drop.pinned ? 0 : 1) || 1;
    if (!keep.pinned) {
      keep.x -= nx * pen * (1 / inv);
      keep.y -= ny * pen * (1 / inv);
    }
    if (!drop.pinned) {
      drop.x += nx * pen * (1 / inv);
      drop.y += ny * pen * (1 / inv);
    }
    this.burst((keep.x + drop.x) / 2, (keep.y + drop.y) / 2, "#e6d7c3", 12, 0.02);
    this.shock((keep.x + drop.x) / 2, (keep.y + drop.y) / 2, (keep.radius + drop.radius) * 3, 0.35);
    this.shake = Math.min(16, this.shake + 3.5);
    this.sfx = "hit";
    const rocky = (kind: Kind) => kind === "planet" || kind === "asteroid" || kind === "comet";
    if (rel > 0.035 && rocky(keep.kind) && rocky(drop.kind) && this.bodies.length < MAX_BODIES - 6) {
      this.chip(keep, nx, ny);
      this.chip(drop, -nx, -ny);
      this.notice = `${keep.name} e ${drop.name} se estilhaçaram no impacto.`;
    } else {
      this.notice = `${keep.name} bateu em ${drop.name}.`;
    }
  }

  private merge(keep: Body, drop: Body, bothStars: boolean): void {
    const m1 = Math.max(keep.gravMass, 1e-14);
    const m2 = Math.max(drop.gravMass, 1e-14);
    const m = m1 + m2;
    if (!keep.pinned) {
      keep.vx = (keep.vx * m1 + drop.vx * m2) / m;
      keep.vy = (keep.vy * m1 + drop.vy * m2) / m;
    }
    keep.mass += drop.mass;
    keep.gravMass = this.massOf(keep.mass);
    const bothHoles = keep.kind === "black-hole" && drop.kind === "black-hole";
    if (keep.kind !== "black-hole") {
      keep.radius = Math.min(1.4, Math.sqrt(keep.radius * keep.radius + drop.radius * drop.radius));
    } else if (bothHoles) {
      keep.radius = Math.min(40, Math.hypot(keep.radius, drop.radius));
    }
    drop.alive = false;
    if (this.selectedId === drop.id) this.selectedId = keep.id;
    if (bothStars && keep.mass >= 8) {
      this.notice = `${keep.name} e ${drop.name} fundiram e a estrela colapsou.`;
      this.detonate(keep, true);
      return;
    }
    const hole = keep.kind === "black-hole";
    this.burst(keep.x, keep.y, hole ? "#f2d2b0" : keep.color, hole ? 22 : 12, hole ? 0.03 : 0.02);
    this.shock(keep.x, keep.y, keep.radius * (hole ? 6 : 3.2), hole ? 0.7 : 0.4);
    this.shake = Math.min(18, this.shake + (hole ? 7 : 4));
    this.sfx = hole ? "swallow" : "hit";
    this.notice = hole ? `${keep.name} absorveu ${drop.name}.` : `${keep.name} incorporou ${drop.name}.`;
  }

  explode(id: number): void {
    const body = this.body(id);
    if (!body) return;
    if (body.kind === "black-hole") {
      this.burst(body.x, body.y, "#f3d2b2", 28, 0.04);
      this.shock(body.x, body.y, body.radius * 8, 0.8);
      this.notice = `${body.name} não explode. O disco se acendeu.`;
      this.sfx = "boom";
      this.shake = Math.min(14, this.shake + 5);
      return;
    }
    this.detonate(body, false);
  }

  private detonate(body: Body, fromMerge: boolean): void {
    const starLike = body.kind === "star" || body.kind === "neutron" || body.kind === "white-dwarf";
    // Planetary breakup or stellar supernova: layered flashes, a broad shockwave,
    // and hot ejecta in a near-spherical spread.
    const supernova = body.kind === "star" || body.kind === "white-dwarf" || body.kind === "neutron";
    if (supernova) this.supernovaFlash = { x: body.x, y: body.y, age: 0, dur: 2.8 };
    this.burst(body.x, body.y, "#ffffff", supernova ? 360 : 72, supernova ? 0.20 : 0.085);
    this.burst(body.x, body.y, supernova ? "#ff884d" : "#e7a36a", supernova ? 260 : 48, supernova ? 0.16 : 0.07);
    this.burst(body.x, body.y, supernova ? "#8bcfff" : "#aab4c2", supernova ? 180 : 34, supernova ? 0.22 : 0.11);
    this.shock(body.x, body.y, Math.max(1.8, body.radius * (supernova ? 32 : 13)), supernova ? 2.8 : 1.35);
    if (supernova) { this.shock(body.x, body.y, Math.max(1.1, body.radius * 20), 2.2); this.shock(body.x, body.y, Math.max(1.1, body.radius * 11), 1.7); }
    this.shake = supernova ? 26 : 16;
    this.sfx = "boom";
    if (starLike) {
      // Simplified stellar-remnant thresholds in solar masses: low/intermediate
      // mass stars leave white dwarfs; massive stars can leave neutron stars;
      // the most massive progenitors collapse to black holes.
      const previous = body.name;
      const progenitorMass = body.mass;
      const becomesBlackHole = progenitorMass >= 20 || body.kind === "black-hole";
      const becomesNeutron = progenitorMass >= 8 && progenitorMass < 20 && body.kind !== "white-dwarf";
      if (becomesBlackHole) {
        body.kind = "black-hole"; body.skin = "hole";
        body.mass = Math.max(3, progenitorMass * 0.18);
        body.radius = Math.max(0.16, body.radius * 0.45);
        body.color = "#050505"; body.color2 = "#f2d7c0";
        body.name = `Buraco de ${previous}`;
      } else if (becomesNeutron) {
        body.kind = "neutron"; body.skin = "compact";
        body.mass = 1.4; body.radius = 0.07;
        body.color = "#80d9ff"; body.color2 = "#f2fbff";
        body.name = `Nêutron de ${previous}`;
      } else {
        body.kind = "white-dwarf"; body.skin = "compact";
        body.mass = Math.max(0.5, Math.min(1.3, progenitorMass * 0.6));
        body.radius = Math.max(0.055, Math.min(0.09, body.radius * 0.35));
        body.color = "#dcecff"; body.color2 = "#ffffff";
        body.name = `Anã branca de ${previous}`;
      }
      body.gravMass = this.massOf(body.mass);
      body.rings = false;
      this.spew(body, 30);
      const remnant = becomesBlackHole ? "buraco negro" : becomesNeutron ? "estrela de nêutrons" : "anã branca";
      this.notice = fromMerge
        ? `${body.name} restou da fusão.`
        : becomesNeutron || becomesBlackHole
          ? `Supernova de ${previous}! O núcleo virou ${remnant} e ejetou matéria em todas as direções.`
          : `${previous} terminou sua evolução e deixou uma anã branca. Esta estrela não tinha massa suficiente para formar uma estrela de nêutrons.`;
    } else {
      this.notice = supernova
        ? `Supernova! ${body.name} explodiu e espalhou matéria pelo sistema.`
        : `${body.name} explodiu em fragmentos que escapam em todas as direções.`;
      this.spew(body, supernova ? 30 : 22);
      body.alive = false;
      this.bodies = this.bodies.filter((item) => item.alive);
      if (this.selectedId === body.id) this.selectedId = null;
    }
  }

  private spew(origin: Body, count: number): void {
    for (let i = 0; i < count && this.bodies.length < MAX_BODIES; i++) {
      // Golden-angle distribution plus jitter looks like an expanding cloud, not a few spokes.
      const angle = (i / count) * Math.PI * 2 + (Math.random() - 0.5) * 0.38;
      const speed = 0.035 + Math.random() * 0.085 + (i % 3) * 0.012;
      this.make({
        name: `Destroço ${origin.id}.${i + 1}`,
        kind: "asteroid",
        skin: "dust",
        mass: Math.max(origin.mass * 0.01, 1e-9) / count,
        radius: Math.max(0.018, origin.radius * (0.09 + Math.random() * 0.18)),
        x: origin.x + Math.cos(angle) * (origin.radius + 0.08),
        y: origin.y + Math.sin(angle) * (origin.radius + 0.08),
        vx: origin.vx + Math.cos(angle) * speed,
        vy: origin.vy + Math.sin(angle) * speed,
        color: ["#b4a89c", "#e7c7a3", "#8c98a8", "#f0e3d2"][i % 4],
        color2: "#6a625a",
      });
    }
  }

  private chip(body: Body, nx: number, ny: number): void {
    if (this.bodies.length >= MAX_BODIES || body.radius < 0.05 || body.mass < 1e-12) return;
    body.mass *= 0.86;
    body.gravMass = this.massOf(body.mass);
    body.radius *= 0.9;
    this.make({
      name: `Lasca de ${body.name}`,
      kind: "asteroid",
      skin: "dust",
      mass: Math.max(body.mass * 0.08, 1e-10),
      radius: Math.max(0.03, body.radius * 0.35),
      x: body.x + nx * (body.radius + 0.06),
      y: body.y + ny * (body.radius + 0.06),
      vx: body.vx + nx * 0.03,
      vy: body.vy + ny * 0.03,
      color: body.color2,
      color2: "#5e584f",
    });
  }

  remove(id: number): void {
    const body = this.body(id);
    if (!body) return;
    this.notice = `${body.name} removido.`;
    this.bodies = this.bodies.filter((item) => item.id !== id);
    if (this.selectedId === id) this.selectedId = null;
    if (this.dragId === id) this.dragId = null;
  }

  togglePin(id: number): void {
    const body = this.body(id);
    if (!body) return;
    body.pinned = !body.pinned;
    this.notice = body.pinned ? `${body.name} fixado no lugar. Ainda atrai.` : `${body.name} solto.`;
  }

  duplicate(id: number): void {
    const body = this.body(id);
    if (!body || this.bodies.length >= MAX_BODIES) return;
    const copy = this.make({
      name: `${body.name} cópia`,
      kind: body.kind,
      skin: body.skin,
      mass: body.mass,
      radius: body.radius,
      x: body.x + 0.45,
      y: body.y + 0.28,
      vx: body.vx,
      vy: body.vy,
      color: body.color,
      color2: body.color2,
      rings: body.rings,
      catalogId: body.catalogId,
      note: body.note,
    });
    this.selectedId = copy.id;
  }

  spawnAt(kind: Kind, x: number, y: number, vx: number, vy: number): Body | null {
    if (this.bodies.length >= MAX_BODIES) {
      this.notice = "A cena está cheia. Apague algum corpo.";
      return null;
    }
    const spec = SPAWN[kind];
    const body = this.make({
      name: spec.name,
      kind,
      skin: spec.skin,
      mass: spec.mass,
      radius: spec.radius,
      x,
      y,
      vx,
      vy,
      color: spec.color,
      color2: spec.color2,
    });
    this.selectedId = body.id;
    this.notice = `${body.name} lançado.`;
    return body;
  }

  throwMeteor(x: number, y: number, vx: number, vy: number): void {
    if (this.bodies.length >= MAX_BODIES) {
      this.notice = "A cena está cheia. Apague algum corpo.";
      return;
    }
    const heavy = Math.hypot(vx, vy) > 0.08;
    const body = this.make({
      name: heavy ? "Meteoro grande" : "Meteoro",
      kind: "asteroid",
      skin: "dust",
      mass: heavy ? 8e-6 : 4e-8,
      radius: heavy ? 0.09 : 0.045,
      x,
      y,
      vx,
      vy,
      color: "#c4b3a4",
      color2: "#6e6258",
      note: "Corpo lançado à mão. A ponta da seta é a velocidade.",
    });
    this.selectedId = body.id;
    this.notice = heavy ? "Meteoro pesado a caminho." : "Meteoro a caminho.";
  }

  replaceAnchor(entry: CatalogEntry, realHorizon: boolean): void {
    let host = this.bodies.find((body) => body.anchor) ?? this.bodies.find((body) => body.kind === "star");
    if (!host) {
      host = this.make({
        name: entry.name,
        kind: "black-hole",
        skin: "hole",
        mass: entry.mass,
        radius: 0.2,
        x: this.camera.x,
        y: this.camera.y,
        color: "#000000",
        color2: "#f0d2b4",
        anchor: true,
      });
    }
    this.applyCatalog(host, entry, realHorizon);
    this.selectedId = host.id;
    this.notice = realHorizon
      ? `${entry.name} ocupou o centro com o horizonte em escala real.`
      : `${entry.name} está no lugar do Sol. Gravidade ${this.massMode === "real" ? "real" : "observável"}.`;
  }

  dropCatalog(entry: CatalogEntry, x: number, y: number): void {
    if (this.bodies.length >= MAX_BODIES) return;
    const body = this.make({
      name: entry.name,
      kind: entry.category,
      skin: entry.skin,
      mass: entry.mass,
      radius: entry.category === "black-hole" ? gameplayHoleRadius(entry.mass) : entry.category === "neutron" ? 0.07 : Math.max(0.12, Math.cbrt(entry.mass) * 0.18),
      x,
      y,
      color: entry.color,
      color2: entry.color2,
      catalogId: entry.id,
      note: entry.fact,
    });
    this.selectedId = body.id;
    this.notice = `${entry.name} solto no atelier.`;
  }

  applyRealHorizon(id: number): void {
    const body = this.body(id);
    if (!body) return;
    const rs = schwarzschildAU(body.mass);
    body.radius = Math.max(rs, 0.03);
    body.kind = "black-hole";
    body.skin = "hole";
    this.notice =
      rs > 2
        ? `Horizonte real aplicado: ${body.radius.toFixed(0)} UA. O que estava dentro já é parte dele.`
        : "Horizonte real aplicado. Em buracos estelares ele é menor que um pixel — o raio de jogo não encolhe abaixo de 0,03 UA.";
  }

  private applyCatalog(body: Body, entry: CatalogEntry, realHorizon: boolean): void {
    body.kind = entry.category;
    body.skin = entry.skin;
    body.name = entry.name;
    body.mass = entry.mass;
    body.gravMass = this.massOf(entry.mass);
    body.radius = entry.category === "black-hole"
      ? (realHorizon ? Math.max(schwarzschildAU(entry.mass), 0.03) : gameplayHoleRadius(entry.mass))
      : entry.category === "neutron" ? 0.07 : Math.max(0.12, Math.cbrt(entry.mass) * 0.18);
    body.color = entry.color;
    body.color2 = entry.color2;
    body.rings = false;
    body.catalogId = entry.id;
    body.note = entry.fact;
    body.anchor = true;
    body.orbitA = undefined;
  }

  hit(wx: number, wy: number, k: number): Body | null {
    const slop = 18 / Math.max(k, 1);
    let best: Body | null = null;
    let bestD = Infinity;
    for (const body of this.bodies) {
      const reach = Math.max(body.radius, slop);
      const d = Math.hypot(body.x - wx, body.y - wy);
      if (d <= reach && d < bestD) {
        best = body;
        bestD = d;
      }
    }
    return best;
  }

  body(id: number | null): Body | undefined {
    if (id == null) return undefined;
    return this.bodies.find((item) => item.id === id);
  }

  heaviest(): Body | undefined {
    return this.bodies.reduce<Body | undefined>((best, body) => (!best || body.mass > best.mass ? body : best), undefined);
  }

  anchor(): Body | undefined {
    return this.bodies.find((body) => body.anchor);
  }

  fit(width: number, height: number, mode: "inner" | "jupiter" | "all"): void {
    const pad = 72;
    let list = this.bodies;
    if (mode === "inner") list = this.bodies.filter((body) => Math.hypot(body.x, body.y) < 3.4 || body.anchor);
    else if (mode === "jupiter") list = this.bodies.filter((body) => Math.hypot(body.x, body.y) < 5.6 || body.anchor);
    if (list.length === 0) {
      this.camera.x = 0;
      this.camera.y = 0;
      this.camera.k = 150;
      return;
    }
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const body of list) {
      minX = Math.min(minX, body.x - body.radius * 1.6);
      maxX = Math.max(maxX, body.x + body.radius * 1.6);
      minY = Math.min(minY, body.y - body.radius * 1.6);
      maxY = Math.max(maxY, body.y + body.radius * 1.6);
    }
    const span = Math.max(maxX - minX, maxY - minY, 0.8);
    this.camera.x = (minX + maxX) / 2;
    this.camera.y = (minY + maxY) / 2;
    this.camera.k = clamp((Math.min(width, height) - pad) / span, 6, 720);
  }

  zoomAt(sx: number, sy: number, width: number, height: number, factor: number): void {
    const before = this.screenToWorld(sx, sy, width, height);
    this.camera.k = clamp(this.camera.k * factor, 4, 1100);
    const after = this.screenToWorld(sx, sy, width, height);
    this.camera.x += before.x - after.x;
    this.camera.y += before.y - after.y;
  }

  screenToWorld(sx: number, sy: number, width: number, height: number): { x: number; y: number } {
    return {
      x: (sx - width / 2) / this.camera.k + this.camera.x,
      y: (sy - height / 2) / this.camera.k + this.camera.y,
    };
  }

  worldToScreen(wx: number, wy: number, width: number, height: number): { x: number; y: number } {
    return {
      x: (wx - this.camera.x) * this.camera.k + width / 2,
      y: (wy - this.camera.y) * this.camera.k + height / 2,
    };
  }

  recordTrails(): void {
    if (!this.trails) return;
    for (const body of this.bodies) {
      const last = body.trail[body.trail.length - 1];
      if (!last || Math.hypot(last.x - body.x, last.y - body.y) > 0.012) {
        body.trail.push({ x: body.x, y: body.y });
        if (body.trail.length > 70) body.trail.shift();
      }
    }
  }

  private burst(x: number, y: number, color: string, count: number, speed: number): void {
    for (let i = 0; i < count && this.particles.length < MAX_PARTICLES; i++) {
      const angle = Math.random() * Math.PI * 2;
      const sp = speed * (0.3 + Math.random());
      const life = 0.55 + Math.random() * 0.75;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * sp,
        vy: Math.sin(angle) * sp,
        life,
        max: life,
        size: 0.015 + Math.random() * 0.035,
        color,
      });
    }
  }

  private shock(x: number, y: number, radius: number, dur: number): void {
    this.shocks.push({ x, y, age: 0, dur, radius });
    if (this.shocks.length > 12) this.shocks.shift();
  }

  private updateFx(days: number, dtReal: number): void {
    for (const particle of this.particles) {
      particle.x += particle.vx * days;
      particle.y += particle.vy * days;
      particle.life -= dtReal;
    }
    if (this.particles.length) this.particles = this.particles.filter((particle) => particle.life > 0);
    for (const shock of this.shocks) shock.age += dtReal;
    if (this.supernovaFlash) { this.supernovaFlash.age += dtReal; if (this.supernovaFlash.age >= this.supernovaFlash.dur) this.supernovaFlash = null; }
    if (this.shocks.length) this.shocks = this.shocks.filter((shock) => shock.age < shock.dur);
  }

  toJSON(): string {
    return JSON.stringify({
      v: 1,
      time: this.time,
      timescale: this.timescale,
      massMode: this.massMode,
      camera: this.camera,
      bodies: this.bodies.map(({ trail: _trail, alive: _alive, ...body }) => body),
    });
  }

  fromJSON(raw: string): boolean {
    try {
      const data = JSON.parse(raw) as {
        v: number;
        time: number;
        timescale: number;
        massMode: MassMode;
        camera: { x: number; y: number; k: number };
        bodies: Array<Omit<Body, "trail" | "alive">>;
      };
      if (data.v !== 1 || !Array.isArray(data.bodies)) return false;
      this.bodies = data.bodies.map((body) => ({ ...body, alive: true, trail: [] }));
      this.time = data.time || 0;
      this.timescale = data.timescale || 90;
      this.massMode = data.massMode === "real" ? "real" : "play";
      this.camera = data.camera || this.camera;
      this.nextId = this.bodies.reduce((max, body) => Math.max(max, body.id), 0) + 1;
      this.particles = [];
      this.shocks = [];
      this.selectedId = null;
      for (const body of this.bodies) body.gravMass = this.massOf(body.mass);
      this.notice = "Cena restaurada neste navegador.";
      return true;
    } catch {
      return false;
    }
  }
}

export function gameplayHoleRadius(mass: number): number {
  const g = playableMass(Math.max(mass, 1));
  return clamp(0.18 + 0.045 * Math.log10(g), 0.16, 0.62);
}

export function flingVelocity(dxAu: number, dtSeconds: number): number {
  const dt = Math.max(dtSeconds, 1 / 120);
  return (dxAu / dt) * 0.011;
}

const SPAWN: Record<Kind, { name: string; mass: number; radius: number; color: string; color2: string; skin: Skin }> = {
  star: { name: "Estrela", mass: 1.2, radius: 0.3, color: "#ffe0b0", color2: "#ff9a45", skin: "star" },
  planet: { name: "Planeta", mass: 3e-6, radius: 0.11, color: "#6e93c4", color2: "#3c6a48", skin: "rock" },
  gas: { name: "Gigante", mass: 4e-4, radius: 0.24, color: "#e2c398", color2: "#9a7048", skin: "bands" },
  comet: { name: "Cometa", mass: 1e-10, radius: 0.05, color: "#e5eef3", color2: "#9eb0be", skin: "comet" },
  asteroid: { name: "Asteroide", mass: 2e-8, radius: 0.05, color: "#9c9186", color2: "#5c564e", skin: "dust" },
  "white-dwarf": { name: "Anã branca", mass: 0.6, radius: 0.07, color: "#e7f0ff", color2: "#b9cbe8", skin: "compact" },
  neutron: { name: "Nêutron", mass: 1.4, radius: 0.06, color: "#d5e6ff", color2: "#8eadd4", skin: "compact" },
  "black-hole": { name: "Buraco negro", mass: 12, radius: 0.18, color: "#000000", color2: "#f0d2b4", skin: "hole" },
};

export function describeCatalog(id: string | undefined): string | undefined {
  if (!id) return undefined;
  return catalogById(id)?.fact;
}

export { YEAR };
function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}
