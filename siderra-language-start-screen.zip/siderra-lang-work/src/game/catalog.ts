import { formatAU, formatMass, schwarzschildAU } from "@/game/units";

export type CatalogEntry = {
  id: string;
  name: string;
  mass: number;
  kindLabel: string;
  distance: string;
  fact: string;
  /** stellar = horizon << Sun; galactic = around the inner system; ultra = swallows the outer system */
  regime: "stellar" | "galactic" | "ultra";
  category: "star" | "neutron" | "black-hole";
  skin: "star" | "compact" | "hole";
  color: string;
  color2: string;
};

export const CATALOG: CatalogEntry[] = [
  {
    id: "gaia-bh1",
    name: "Gaia BH1",
    mass: 9.62,
    kindLabel: "Estelar · o mais próximo conhecido",
    distance: "cerca de 1.560 anos-luz",
    fact: "Buraco negro adormecido. Foi achado em 2022 pelo bamboleio de uma estrela parecida com o Sol, que o orbita a cada 186 dias. Não há disco brilhante — só a gravidade.",
    regime: "stellar",
    category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4",
  },
  {
    id: "gaia-bh3",
    name: "Gaia BH3",
    mass: 33,
    kindLabel: "Estelar · o mais massivo da Via Láctea",
    distance: "cerca de 1.930 anos-luz, na Águia",
    fact: "Descoberto em 2024. Cerca de 33 massas solares, com uma estrela gigante antiga numa órbita de 11,6 anos. Até então, Cygnus X-1 era o recorde estelar da galáxia.",
    regime: "stellar",
    category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4",
  },
  {
    id: "cygnus-x1",
    name: "Cygnus X-1",
    mass: 21.2,
    kindLabel: "Estelar · o clássico",
    distance: "cerca de 7.200 anos-luz",
    fact: "O primeiro buraco negro amplamente aceito, no início dos anos 1970. Suga vento de uma supergigante azul e brilha em raios X. O horizonte tem cerca de 125 km de diâmetro — tamanho de cidade, não de estrela.",
    regime: "stellar",
    category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4",
  },
  {
    id: "gw190521",
    name: "GW190521",
    mass: 142,
    kindLabel: "Remanescente de fusão",
    distance: "bilhões de anos-luz · só onda gravitacional",
    fact: "Em 2019, LIGO e Virgo ouviram a fusão de dois buracos negros de cerca de 85 e 66 massas solares. O resultado tem cerca de 142 sóis. Nada de luz: o registro é o tremor do espaço.",
    regime: "stellar",
    category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4",
  },
  {
    id: "sgr-a",
    name: "Sagitário A*",
    mass: 4.297e6,
    kindLabel: "Supermassivo · centro da Via Láctea",
    distance: "26.700 anos-luz",
    fact: "A estrela S2 completa uma volta em cerca de 16 anos e chega a 2,5% da velocidade da luz. O Telescópio do Horizonte de Eventos publicou o anel em 2022. Ghez e Genzel dividiram o Nobel de 2020 por essas órbitas.",
    regime: "galactic",
    category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4",
  },
  {
    id: "m87",
    name: "M87*",
    mass: 6.5e9,
    kindLabel: "Supermassivo · a primeira imagem",
    distance: "55 milhões de anos-luz, em Virgem",
    fact: "Em abril de 2019 virou a primeira fotografia de um horizonte. Um jato de plasma sai do núcleo e atravessa a galáxia. O diâmetro do horizonte cabe cerca de quatro vezes a largura da órbita de Netuno.",
    regime: "ultra",
    category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4",
  },
  {
    id: "oj287",
    name: "OJ 287",
    mass: 1.8e10,
    kindLabel: "Binário supermassivo",
    distance: "cerca de 3,5 bilhões de anos-luz",
    fact: "Quasar que pisca a cada 12 anos. O modelo mais aceito é um buraco negro menor atravessando o disco de um maior, de cerca de 18 bilhões de massas solares. A massa ainda é modelo, não uma balança.",
    regime: "ultra",
    category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4",
  },
  {
    id: "ton-618",
    name: "TON 618",
    mass: 4.07e10,
    kindLabel: "Quasar ultramassivo",
    distance: "a luz viajou 10,8 bilhões de anos (z = 2,219)",
    fact: "A estimativa de 2019, pela linha C IV, dá 40,7 bilhões de massas solares. Um trabalho de 2004, pela Hβ, chegou a 66 bilhões — o número que ainda circula. É inferência de uma linha espectral, com incerteza de um fator de alguns.",
    regime: "ultra",
    category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4",
  },
  {
    id: "phoenix-a",
    name: "Phoenix A",
    mass: 1e11,
    kindLabel: "Estimativa incerta · talvez o maior",
    distance: "no aglomerado de Fênix, a bilhões de anos-luz",
    fact: "Há quem cite perto de 100 bilhões de massas solares a partir da luminosidade do núcleo. A conta é indireta e discutida. Entra aqui como teto: um horizonte ainda maior que o de TON 618, se a estimativa alta estiver certa.",
    regime: "ultra",
    category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4",
  },
  { id: "sun", name: "Sol", mass: 1, kindLabel: "Estrela · sequência principal", distance: "8 minutos-luz da Terra", fact: "Nossa estrela: uma anã amarela de cerca de 4,6 bilhões de anos, fonte de luz e energia do Sistema Solar.", regime: "stellar", category: "star", skin: "star", color: "#ffb347", color2: "#fff0b5" },
  { id: "sirius-a", name: "Sírius A", mass: 2.06, kindLabel: "Estrela · sequência principal", distance: "8,6 anos-luz", fact: "A estrela mais brilhante do céu noturno vista da Terra. É uma estrela branca da sequência principal, acompanhada pela anã branca Sírius B.", regime: "stellar", category: "star", skin: "star", color: "#b9d9ff", color2: "#f4f8ff" },
  { id: "betelgeuse", name: "Betelgeuse", mass: 16.5, kindLabel: "Supergigante vermelha", distance: "cerca de 550 anos-luz", fact: "Supergigante vermelha variável em Orion. Está em fase avançada e deverá terminar sua vida em uma supernova, mas não há previsão de explosão iminente em escala humana.", regime: "stellar", category: "star", skin: "star", color: "#ff6b45", color2: "#ffd0a1" },
  { id: "rigel", name: "Rigel", mass: 21, kindLabel: "Supergigante azul", distance: "cerca de 860 anos-luz", fact: "Uma supergigante azul extremamente luminosa na constelação de Orion.", regime: "stellar", category: "star", skin: "star", color: "#82b9ff", color2: "#eaf5ff" },
  { id: "crab-pulsar", name: "Pulsar do Caranguejo", mass: 1.4, kindLabel: "Estrela de nêutrons · pulsar", distance: "cerca de 6.500 anos-luz", fact: "O núcleo remanescente da supernova observada em 1054. Gira cerca de 30 vezes por segundo e emite pulsos regulares de radiação.", regime: "stellar", category: "neutron", skin: "compact", color: "#b9dcff", color2: "#eaf6ff" },
  { id: "vela-pulsar", name: "Pulsar de Vela", mass: 1.4, kindLabel: "Estrela de nêutrons · pulsar", distance: "cerca de 950 anos-luz", fact: "Estrela de nêutrons jovem no remanescente de supernova de Vela, com rotação rápida e emissão pulsada.", regime: "stellar", category: "neutron", skin: "compact", color: "#8fc7ff", color2: "#eaf6ff" },
  { id: "geminga", name: "Geminga", mass: 1.4, kindLabel: "Estrela de nêutrons · pulsar", distance: "cerca de 800 anos-luz", fact: "Pulsar próximo, brilhante em raios gama, que ajuda a estudar estrelas de nêutrons isoladas.", regime: "stellar", category: "neutron", skin: "compact", color: "#c3b7ff", color2: "#f4f0ff" },
  { id: "sirius-b", name: "Sírius B", mass: 1.02, kindLabel: "Anã branca", distance: "8,6 anos-luz", fact: "Companheira compacta de Sírius A. Tem massa próxima à do Sol comprimida num volume semelhante ao da Terra.", regime: "stellar", category: "star", skin: "star", color: "#a9d5ff", color2: "#f5fbff" },
  { id: "proxima-centauri", name: "Próxima Centauri", mass: 0.122, kindLabel: "Anã vermelha", distance: "4,24 anos-luz", fact: "A estrela mais próxima do Sol. É pequena, fria em comparação com o Sol e conhecida por hospedar planetas.", regime: "stellar", category: "star", skin: "star", color: "#e45a43", color2: "#ffb18a" },
  { id: "vega", name: "Vega", mass: 2.1, kindLabel: "Estrela branca-azulada", distance: "25 anos-luz", fact: "Uma das estrelas mais brilhantes do céu e referência importante para calibração fotométrica.", regime: "stellar", category: "star", skin: "star", color: "#9ccaff", color2: "#f4f8ff" },
  { id: "polaris", name: "Polaris", mass: 5.4, kindLabel: "Supergigante amarela", distance: "cerca de 440 anos-luz", fact: "A Estrela Polar é uma estrela variável pulsante e faz parte de um sistema múltiplo.", regime: "stellar", category: "star", skin: "star", color: "#ffd17a", color2: "#fff4cf" },
  { id: "antares", name: "Antares", mass: 12, kindLabel: "Supergigante vermelha", distance: "cerca de 550 anos-luz", fact: "Uma supergigante vermelha de grande raio aparente, na constelação de Escorpião.", regime: "stellar", category: "star", skin: "star", color: "#e84f36", color2: "#ffbc82" },
  { id: "psr-b1919", name: "PSR B1919+21", mass: 1.4, kindLabel: "Estrela de nêutrons · pulsar", distance: "cerca de 2.300 anos-luz", fact: "Um dos primeiros pulsares descobertos, em 1967; seus pulsos regulares revelaram uma nova classe de objetos compactos.", regime: "stellar", category: "neutron", skin: "compact", color: "#83d8ff", color2: "#f0fcff" },
  { id: "psr-j0218", name: "PSR J0218+4232", mass: 1.6, kindLabel: "Estrela de nêutrons · milissegundo", distance: "milhares de anos-luz", fact: "Pulsar de milissegundo que gira centenas de vezes por segundo; massa e distância têm incertezas observacionais.", regime: "stellar", category: "neutron", skin: "compact", color: "#9fa8ff", color2: "#f4f0ff" },
  { id: "gw150914", name: "GW150914", mass: 62, kindLabel: "Remanescente de fusão", distance: "cerca de 1,3 bilhão de anos-luz", fact: "O sinal histórico observado em 2015 foi produzido pela fusão de dois buracos negros, a primeira detecção direta de ondas gravitacionais.", regime: "stellar", category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4" },
  { id: "lmc-x3", name: "LMC X-3", mass: 7, kindLabel: "Buraco negro estelar candidato", distance: "Grande Nuvem de Magalhães", fact: "Sistema binário de raios X estudado por sua estrela companheira e pela emissão do material que cai em direção ao objeto compacto.", regime: "stellar", category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4" },
  { id: "ngc-1277", name: "NGC 1277*", mass: 5e9, kindLabel: "Supermassivo · estimativa discutida", distance: "cerca de 220 milhões de anos-luz", fact: "O buraco negro central desta galáxia teve estimativas de massa muito altas; medições e interpretações posteriores variam.", regime: "ultra", category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4" },
  { id: "holmberg-15a", name: "Holmberg 15A*", mass: 4e10, kindLabel: "Supermassivo · núcleo de galáxia", distance: "centenas de milhões de anos-luz", fact: "Um buraco negro central extremamente massivo, cuja estimativa depende de modelagem dinâmica da galáxia hospedeira.", regime: "ultra", category: "black-hole", skin: "hole", color: "#050505", color2: "#f0d2b4" },
];

export function catalogById(id: string): CatalogEntry | undefined {
  return CATALOG.find((entry) => entry.id === id);
}

export function horizonCaption(entry: CatalogEntry): string {
  if (entry.category === "star") return `${entry.name}: ${entry.kindLabel}. Distância: ${entry.distance}. Massa aproximada: ${formatMass(entry.mass)}. ${entry.fact}`;
  if (entry.category === "neutron") return `${entry.name}: ${entry.kindLabel}. Distância: ${entry.distance}. Massa aproximada: ${formatMass(entry.mass)}. ${entry.fact}`;
  const rs = schwarzschildAU(entry.mass);
  const diamKm = entry.mass * RS_DIAM_FACTOR;
  if (entry.regime === "stellar") {
    const sunWidths = 1_392_000 / diamKm;
    return `Horizonte de Schwarzschild: raio ${formatKm(diamKm / 2)}, diâmetro ${formatKm(diamKm)}. O Sol é cerca de ${Math.max(1, Math.round(sunWidths)).toLocaleString("pt-BR")} vezes mais largo. Massa usada: ${formatMass(entry.mass)}.`;
  }
  const neptune = 30.07;
  const fits = rs / neptune;
  return `Raio do horizonte: ${formatAU(rs)} (${formatKm(rs * 149_597_870.7)}). A órbita de Netuno, a 30 UA, cabe cerca de ${trimNum(fits)} vezes nesse raio. Massa usada: ${formatMass(entry.mass)}.`;
}

const RS_DIAM_FACTOR = 2.95325 * 2;

function formatKm(km: number): string {
  if (km >= 1e9) return `${trimNum(km / 1e9)} bilhões de km`;
  if (km >= 1e6) return `${trimNum(km / 1e6)} milhões de km`;
  if (km >= 1e3) return `${Math.round(km).toLocaleString("pt-BR")} km`;
  return `${Math.round(km)} km`;
}

function trimNum(n: number): string {
  const text = n >= 100 ? n.toFixed(0) : n >= 10 ? n.toFixed(1) : n.toFixed(2);
  return text.replace(".", ",").replace(/,0$/, "");
}
