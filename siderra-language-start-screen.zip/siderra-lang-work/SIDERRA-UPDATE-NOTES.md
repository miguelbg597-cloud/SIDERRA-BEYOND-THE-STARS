# Siderra: Beyond the Stars — atualização incremental

## Incluído nesta primeira etapa
- Fundo com nebulosas decorativas animadas, ativáveis/desativáveis no painel **Cena > Universo**.
- Novo preset **Asterion · fictício**, com uma estrela e cinco mundos fictícios, incluindo Miller, Mann e Edmunds como referências de ficção científica (não são órbitas reais).
- Botão **Evento cósmico**, que provoca uma explosão/efeito no astro selecionado (ou no primeiro astro disponível).
- Atalho **Mapa · ver tudo**, que ajusta a câmera para enquadrar o sistema.
- O catálogo científico que já existia foi preservado.

## Próximas etapas planejadas
- Fichas científicas mais completas para todos os tipos de corpo.
- Evolução estelar guiada e eventos com escolha/confirmação para evitar explosões acidentais.
- Mapa de sistemas navegável e mais sistemas fictícios.
- Eventos ambientais adicionais, como cometas, chuvas de meteoros e supernovas com resíduos.
- Melhorias de gravidade e trilhas orbitais.

## Nota de teste
O ambiente de dependências não terminou de instalar durante a verificação; portanto, esta versão não foi validada com `npm run build`. Teste primeiro em uma cópia/preview antes de substituir a versão publicada.
