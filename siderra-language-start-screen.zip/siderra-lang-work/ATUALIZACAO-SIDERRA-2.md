# Siderra: Beyond the Stars — atualização 2

## Novidades desta versão
- Nebulosas suaves ativáveis no painel Cena > Universo.
- Sistema fictício Asterion com Miller, Bruma, Mann, Edmunds e Nácar.
- Evento de explosão/efeito cósmico.
- Chuva de meteoros: adiciona cinco asteroides à cena.
- Mapa navegável no painel Cena: toque no nome de um astro para selecioná-lo e focar a câmera nele.
- Ficha científica do astro selecionado com classe, massa, distância, velocidade e estado da simulação.
- Evolução estelar ilustrativa, avançando entre estrela, anã branca, estrela de nêutrons e buraco negro. É uma sequência educativa simplificada, não uma previsão física; a evolução real depende da massa inicial.

## Observações
- Projeto 2D preservado.
- O sistema Asterion é fictício; os valores do modelo do jogo não devem ser interpretados como dados astronômicos medidos.
- A instalação das dependências e o build não puderam ser concluídos neste ambiente porque o cache local do npm está incompleto e o acesso ao registro falhou. Teste em uma prévia antes de publicar no site principal.

## Atualização visual: buracos negros supermassivos e jatos
- Buracos negros com massa de pelo menos 1 milhão de massas solares recebem disco de acreção azul/branco maior e dois jatos bipolares em pixel art, com pulsação visual.
- Buracos negros estelares mantêm disco mais compacto em tons avermelhados/dourados e não exibem os jatos longos.
- O critério visual usa a massa do objeto já existente no catálogo/simulação; não altera massa, gravidade ou evolução física.
- Verificação de build não executada neste ambiente porque as dependências do projeto não estão instaladas.
